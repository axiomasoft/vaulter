<?php

declare(strict_types=1);

namespace Vaulter\Tests\Access;

use Illuminate\Support\Carbon;
use Vaulter\Enums\Access\Effect;
use Vaulter\Enums\Access\GrantLevel;
use Vaulter\Enums\Access\GrantScope;
use Vaulter\Enums\Drive\NodeKind;
use Vaulter\Facades\Vaulter;
use Vaulter\Models\Access\NodeGrant;
use Vaulter\Models\Drive\Node;
use Vaulter\Models\Drive\Storage;
use Vaulter\Tests\Drive\DriveTestHelpers;
use Vaulter\Tests\Fixtures\TestUser;

/**
 * Builders for the M2a ACL tests: a storage with a known tree, a subject user, and
 * a one-liner grant writer. Keeps the table-driven tests focused on the algorithm,
 * not on row plumbing.
 */
final class AccessTestHelpers
{
    /**
     * A fresh storage (and its root node) for a unique host entity.
     */
    public static function storage(): Storage
    {
        return Vaulter::for(DriveTestHelpers::host())->storage();
    }

    /**
     * A persisted test user with a fixed id (the grant subject / actor).
     */
    public static function user(int $id = 1): TestUser
    {
        $user = new TestUser;
        $user->forceFill(['id' => $id]);
        $user->exists = true;

        return $user;
    }

    /**
     * Create a folder node directly under a parent (or the storage root), bypassing
     * the Action so a test can shape an arbitrary tree without name-conflict noise.
     */
    public static function folder(Storage $storage, ?Node $parent, string $name, bool $inheritGrants = true): Node
    {
        $model = config('vaulter.models.node');

        /** @var Node $node */
        $node = new $model;
        $node->forceFill([
            'storage_id' => $storage->id,
            'parent_id' => $parent?->id ?? $storage->root_node_id,
            'kind' => NodeKind::Folder,
            'name' => $name,
            'inherit_grants' => $inheritGrants,
        ])->save();

        return $node->refresh();
    }

    /**
     * Write a grant row directly (the resolver reads these). $subjectId defaults to
     * the canonical test user (id 1).
     */
    public static function grant(
        Node $node,
        GrantLevel $level,
        Effect $effect = Effect::Allow,
        GrantScope $scope = GrantScope::Subtree,
        int $permissions = 0,
        int|string $subjectId = 1,
        ?string $subjectType = null,
        ?Carbon $expiresAt = null,
    ): NodeGrant {
        $subjectType ??= (new TestUser)->getMorphClass();

        $model = config('vaulter.models.grant');

        /** @var NodeGrant $grant */
        $grant = new $model;
        $grant->forceFill([
            'node_id' => $node->id,
            'subject_type' => $subjectType,
            'subject_id' => $subjectId,
            'level' => $level->value,
            'permissions' => $permissions,
            'effect' => $effect->value,
            'scope' => $scope->value,
            'expires_at' => $expiresAt,
        ])->save();

        return $grant->refresh();
    }
}
