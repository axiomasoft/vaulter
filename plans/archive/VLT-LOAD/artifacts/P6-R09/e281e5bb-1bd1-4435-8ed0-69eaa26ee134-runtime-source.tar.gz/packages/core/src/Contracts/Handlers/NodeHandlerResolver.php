<?php

declare(strict_types=1);

namespace Vaulter\Contracts\Handlers;

use Vaulter\Http\Resources\Drive\NodeResource;
use Vaulter\Models\Drive\Node;
use Vaulter\ValueObjects\Handlers\HandlerDescriptor;

/**
 * Resolves the format-handler descriptor for a node (§4.5 / §5 / M4a) — the (id +
 * capabilities + ui) bundle {@see NodeResource} embeds
 * and the GET .../handler endpoint returns, so the Vue client routes the node to the
 * right editor/preview/download surface without re-running mime logic client-side.
 *
 * Both the contract and the concrete resolver (`Vaulter\Engines\NodeHandlerResolver`,
 * backed by the core-owned `Vaulter\Engines\DocumentHandlerRegistry`) are core-owned
 * since VLT-CANON P0.4 (D10, superseding H.5/T5 — a drive-only host with no
 * vaulter-documents installed still resolves a real preview/download descriptor
 * through this seam, never null). {@see NodeResource::handler()} resolves it
 * unconditionally for every leaf node. A folder node is never passed here — only
 * called for leaf (file/document) nodes. vaulter-documents (or another package)
 * contributes richer formats (TipTap, Univer, …) by tagging handlers into the same
 * registry — it never rebinds this seam.
 */
interface NodeHandlerResolver
{
    public function describe(Node $node, ?string $detectedMime = null): HandlerDescriptor;
}
