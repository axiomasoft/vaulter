<?php

declare(strict_types=1);

namespace Vaulter\Repositories\Drive;

use Illuminate\Database\Eloquent\Model;
use Vaulter\Models\Drive\Storage;
use Vaulter\Support\Config;
use Vaulter\Support\Identity;

/**
 * Read-side lookups over v_storages (§2.1). The get-or-create entry point is the
 * StorageManager; this repository just resolves the existing row for a host
 * entity within a panel (the idempotency key behind the partial-unique index on
 * owner_type/owner_id/panel).
 *
 * SCOPED-singleton bound (P1.3 / F-P4.2-03) — `find()` memoizes by id in an
 * in-request identity map, so a page of N sibling nodes belonging to the SAME
 * storage (the common case: `AccessResolver::storageOf()` calls this once per
 * node via `abilitiesFor()`) issues exactly ONE `SELECT` for that storage, not N.
 * `scoped()` (not `singleton()`) so the cache resets between requests/jobs on
 * Octane/queue workers rather than leaking across them.
 */
final class StorageReadRepository
{
    /** @var array<string, Storage|null> */
    private array $cache = [];

    public function find(int|string $id): ?Storage
    {
        $key = Identity::stringify($id);

        if (array_key_exists($key, $this->cache)) {
            return $this->cache[$key];
        }

        $model = Config::storageModel();

        return $this->cache[$key] = $model::query()->find($id);
    }

    /**
     * The storage mounted on a host entity within a panel (§2.1) — the
     * polymorphic owner triple (owner_type, owner_id, panel) is the idempotency
     * key. Returns null when none exists yet (the manager then provisions one).
     */
    public function forOwner(Model $owner, string $panel): ?Storage
    {
        $model = Config::storageModel();

        return $model::query()
            ->where('owner_type', $owner->getMorphClass())
            ->where('owner_id', $owner->getKey())
            ->where('panel', $panel)
            ->first();
    }
}
