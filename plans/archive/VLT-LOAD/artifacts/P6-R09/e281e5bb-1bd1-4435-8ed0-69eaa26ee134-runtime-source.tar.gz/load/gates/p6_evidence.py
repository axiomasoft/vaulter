"""Pure recomputation of R09 evidence. No inferred samples or product success."""
from collections import defaultdict
from math import ceil

WEBHOOK = 'Vaulter\\Jobs\\Webhooks\\DeliverWebhook'


def percentile(values, fraction=.95):
    return sorted(values)[max(0, ceil(len(values) * fraction) - 1)] if values else None


def window(rows, run_id, cell_id, attempt=None):
    return [r for r in rows if r.get('run_id') == run_id and r.get('cell_id') == cell_id
            and (attempt is None or r.get('attempt') == attempt)]


def lifecycle(rows):
    jobs = defaultdict(lambda: defaultdict(list))
    for row in rows:
        if row.get('class') == WEBHOOK:
            jobs[row['uuid']][row['source']].append(row['monotonic_ns'])
    waits, processes, errors = [], [], []
    for uuid, sources in jobs.items():
        queued, started, done = (sources[k] for k in ('queued', 'processing', 'processed'))
        if len(queued) != 1 or len(started) > 1 or len(done) > 1:
            errors.append(uuid)
            continue
        if started:
            wait = (started[0] - queued[0]) / 1e9
            if wait < 0:
                errors.append(uuid)
            else:
                waits.append(wait)
        if done:
            if not started or done[0] < started[0]:
                errors.append(uuid)
            else:
                processes.append((done[0] - started[0]) / 1e9)
    return {'queued': sum(len(s['queued']) for s in jobs.values()),
            'processing': sum(len(s['processing']) for s in jobs.values()),
            'processed': sum(len(s['processed']) for s in jobs.values()),
            'uuids': sorted(jobs), 'invalid_uuids': errors,
            'queue_wait_samples': len(waits), 'queue_wait_p95_seconds': percentile(waits),
            'process_samples': len(processes), 'process_p95_seconds': percentile(processes)}


def failure_delta(before, after):
    known = {r['uuid'] for r in before}
    return [r for r in after if r['uuid'] not in known]


def aggregate_slo(attempts):
    verdicts = {r['slo'] for r in attempts}
    return 'red' if 'red' in verdicts else ('unevaluated' if 'unevaluated' in verdicts else attempts[-1]['slo'])


def validate_volume(volume):
    for field, count, remaining in [('relay_ticks', 'relayed', 'outbox_remaining'),
                                     ('retry_ticks', 'retried', 'due_remaining')]:
        expected = 10000 if count == 'relayed' else 5000
        ticks = volume.get(field, [])
        if not ticks or sum(t.get(count, 0) for t in ticks) != expected or volume.get(remaining) != 0:
            raise ValueError(f'incomplete {field} drain')
        if any(not t.get('ok') or t.get('elapsed_ns', 0) <= 0 for t in ticks):
            raise ValueError(f'failed {field} tick')
    if not volume.get('relay_drained') or not volume.get('retry_drained'):
        raise ValueError('volume queue remains undrained')
    if volume.get('active_endpoints') != 20:
        raise ValueError('volume requires 20 active endpoints')


def product_verdict(row):
    # Cell outcomes alone cannot prove the tier-level throughput/latency contract.
    if row['failed_jobs'] or not row['recovered'] or (row.get('backlog_slope') or 0) > 0 or row.get('duplicate_http', 0):
        return 'red'
    return 'unevaluated'


def slo_report(volume, attempts):
    steady = next(r for r in attempts if r['cell_id'] == 'product-realistic.relay.i20.f1.2xx' and r['attempt'] == 1)
    latency = [r for r in attempts if r.get('sink') == 'slow-under-timeout' and r.get('fanout') == '1' and r.get('ingress_per_s') == 200]
    best = min(latency, key=lambda r: r['jobs_per_second'])
    retry_ticks = volume['retry_ticks']
    failed = sum(r['failed_jobs'] for r in attempts if r['plane'] == 'product-realistic')
    relay_ok = (volume['relay_rows_per_second'] >= 200 and volume['relay_tick_p95_seconds'] <= 1.5
                and volume['relay_drained'] and steady['backlog_slope'] <= 0
                and steady['events_sent'] >= 20 * steady['burst_seconds'] and failed == 0)
    delivery_ok = (best['jobs_per_second'] >= 50 and best['recovered']
                   and best['lifecycle']['queue_wait_p95_seconds'] is not None
                   and best['lifecycle']['queue_wait_p95_seconds'] <= 5
                   and best['lifecycle']['process_p95_seconds'] <= 2 and failed == 0)
    retry_ok = (volume['retry_rows_per_second'] >= 500 and volume['retry_tick_p95_seconds'] <= 2
                and max(t['retried'] for t in retry_ticks) <= 1000
                and all(t.get('rss_peak_bytes') is not None for t in retry_ticks)
                and max(t.get('rss_peak_bytes') or 0 for t in retry_ticks) <= 268435456 and volume['retry_drained']
                and volume['retry_counts']['failed_jobs'] == 0)
    return {'SLO-58': 'green' if relay_ok else 'red', 'SLO-61': 'green' if delivery_ok else 'red',
            'SLO-64': 'green' if retry_ok else 'red',
            'delivery_limiting_cell': best['cell_id'], 'delivery_limiting_attempt': best['attempt'],
            'delivery_min_jobs_per_second': best['jobs_per_second'],
            'daily_error_budget': 'unevaluated: this run is shorter than 24 hours',
            'retry_memory_measure': 'OS process peak RSS from /usr/bin/time; PHP peak recorded separately',
            'tier_M_L': 'unevaluated'}
