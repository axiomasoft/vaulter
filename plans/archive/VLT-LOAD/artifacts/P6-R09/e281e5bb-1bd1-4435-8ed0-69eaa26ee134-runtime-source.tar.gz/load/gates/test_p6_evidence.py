import unittest
from unittest.mock import patch
from pathlib import Path
import tempfile
import p6_evidence as ev
import p6_live_matrix as live


def row(uuid, source, ns, **overrides):
    return {**dict(uuid=uuid, source=source, monotonic_ns=ns, run_id='r', cell_id='c', attempt=1),
            'class': ev.WEBHOOK, **overrides}


class EvidenceTest(unittest.TestCase):
    def test_join_wait_is_enqueue_to_start_not_delivery_age(self):
        result = ev.lifecycle([row('a', 'queued', 1000000000), row('a', 'processing', 3000000000), row('a', 'processed', 3050000000)])
        self.assertEqual(result['queue_wait_p95_seconds'], 2)
        self.assertEqual(result['process_p95_seconds'], .05)
        self.assertEqual(result['processed'], 1)

    def test_missing_or_duplicate_enqueue_cannot_be_valid(self):
        for rows in ([row('a', 'processing', 2)], [row('a', 'queued', 1)] * 2,
                     [row('a', 'queued', 3), row('a', 'processing', 2)]):
            self.assertEqual(ev.lifecycle(rows)['invalid_uuids'], ['a'])

    def test_old_failures_do_not_become_new_cell_failures(self):
        self.assertEqual(ev.failure_delta([{'uuid': 'old'}], [{'uuid': 'old'}, {'uuid': 'new'}]), [{'uuid': 'new'}])

    def test_serial_concurrent_and_attempt_windows_are_disjoint(self):
        rows = [row('a', 'queued', 1), row('b', 'queued', 2, cell_id='next'), row('c', 'queued', 3, attempt=2)]
        self.assertEqual([r['uuid'] for r in ev.window(rows, 'r', 'c', 1)], ['a'])

    def test_later_green_cannot_erase_red_attempt(self):
        self.assertEqual(ev.aggregate_slo([{'slo': 'red'}, {'slo': 'green'}]), 'red')

    def test_single_tick_cannot_prove_10k_drain(self):
        with self.assertRaises(ValueError):
            ev.validate_volume({'relay_ticks': [{'relayed': 100, 'ok': True, 'elapsed_ns': 10}], 'outbox_remaining': 9900})

    def test_context_passed_to_dispatch_process(self):
        import subprocess
        with patch.object(live, 'compose', return_value=subprocess.CompletedProcess([], 0, '{}', '')) as call:
            live.probe('relay')
        self.assertIn('LOAD_QUEUE_CONTEXT=/app/load/seed/out/p6-queue-context.json', call.call_args.args)

    def test_cleanup_waits_for_workers_before_flush_and_delete(self):
        calls = []
        with patch.object(live, 'set_workers', side_effect=lambda _: calls.append('pause')), \
             patch.object(live, 'flush_redis', side_effect=lambda: calls.append('flush')), \
             patch.object(live, 'probe', side_effect=lambda *a, **k: calls.append('delete') or {'ok': True}):
            live.clean_cell('r')
        self.assertEqual(calls, ['pause', 'flush', 'delete'])

    def test_failed_pause_never_deletes_fixture(self):
        with patch.object(live, 'set_workers', side_effect=live.gate.EvidenceInvalid('busy')), \
             patch.object(live, 'probe') as probe, patch.object(live, 'flush_redis') as flush:
            with self.assertRaises(live.gate.EvidenceInvalid):
                live.clean_cell('r')
        probe.assert_not_called()
        flush.assert_not_called()
