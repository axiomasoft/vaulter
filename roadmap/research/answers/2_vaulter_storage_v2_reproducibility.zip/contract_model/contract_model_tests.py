#!/usr/bin/env python3
"""Executable contract model; NOT a PostgreSQL/Yjs/Univer integration or load test.

Only Python's standard library is used. Run:
    python3 contract_model_tests.py --output model_results.json

This deliberately small model checks sequencing, fencing, read semantics and
authorization. Python dictionary replacement represents an atomic publication;
it does not prove SQL isolation, engine behavior, object durability or speed.
"""

from __future__ import annotations

import argparse
import copy
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import sys
from typing import Any


def digest(value: Any) -> str:
    encoded = json.dumps(value, sort_keys=True, ensure_ascii=False, separators=(",", ":"))
    return hashlib.sha256(encoded.encode("utf-8")).hexdigest()


class ContractError(Exception):
    pass


@dataclass(frozen=True)
class Token:
    tenant: str
    document: str
    generation: int
    position: int


@dataclass(frozen=True)
class Receipt:
    command_id: str
    request_hash: str
    source: Token
    after_hash: str


@dataclass(frozen=True)
class Event:
    generation: int
    base: int | None
    target: int
    patch: dict[str, Any]
    full_snapshot: bool = False
    schema: int = 1


class Model:
    """One scoped document; source log/receipts are durable by model assumption."""

    def __init__(self, kind: str = "text") -> None:
        self.tenant = "org-model"
        self.document = "book-model" if kind == "book" else "contract-model"
        self.allowed = {"user-model"}
        self.generation = 3
        self.position = 41
        self.rows = (
            {"B2": 12, "B3": 8, "D2": "=SUM(B2:B3)"}
            if kind == "book" else {"heading": "Оплата", "p17": "Срок 15 дней"}
        )
        self.history = {(3, 41): copy.deepcopy(self.rows)}
        self.receipts: dict[str, Receipt] = {}
        self.events: list[Event] = []
        self.desired_schema = 1
        self.projection = {
            "generation": 3, "position": 41, "version": 1,
            "schema": 1, "ready": True, "rows": copy.deepcopy(self.rows),
        }
        self.calculation = {
            "generation": 3, "position": 41, "revision": 1,
            "engine": "model-only", "D2": 20,
        } if kind == "book" else None

    def authorize(self, user: str) -> None:
        if user not in self.allowed:
            raise ContractError("access_denied")

    def token(self, position: int | None = None) -> Token:
        return Token(self.tenant, self.document, self.generation,
                     self.position if position is None else position)

    def lookup_receipt(self, user: str, command_id: str) -> Receipt:
        self.authorize(user)
        return self.receipts[command_id]

    def execute(self, user: str, command_id: str, expected_generation: int,
                changes: dict[str, Any], expected: dict[str, Any]) -> Receipt:
        self.authorize(user)
        request_hash = digest({"generation": expected_generation,
                               "changes": changes, "expected": expected})
        existing = self.receipts.get(command_id)
        if existing is not None:
            if existing.request_hash != request_hash:
                raise ContractError("idempotency_key_payload_conflict")
            return existing
        if expected_generation != self.generation:
            raise ContractError("generation_changed")
        if any(self.rows.get(key) != value for key, value in expected.items()):
            raise ContractError("precondition_failed")

        before = self.position
        candidate = copy.deepcopy(self.rows)
        candidate.update(copy.deepcopy(changes))
        target = before + 1
        receipt = Receipt(command_id, request_hash, self.token(target), digest(candidate))
        event = Event(self.generation, before, target, copy.deepcopy(changes),
                      schema=self.desired_schema)
        # Represents ONE atomic source transaction: content + receipt + outbox.
        self.rows, self.position = candidate, target
        self.history[(self.generation, target)] = copy.deepcopy(candidate)
        self.receipts[command_id] = receipt
        self.events.append(event)
        return receipt

    def full_event(self, target: int, schema: int | None = None) -> Event:
        return Event(self.generation, None, target, {}, True,
                     self.desired_schema if schema is None else schema)

    def publish(self, event: Event) -> str:
        """Validate every guard BEFORE changing either payload or publication head."""
        if event.generation != self.generation:
            return "stale_generation"
        if event.target > self.position:
            return "future_source"
        if event.schema != self.desired_schema:
            return "obsolete_schema"
        source = self.history.get((event.generation, event.target))
        if source is None:
            return "source_unavailable"
        head = self.projection
        if head["ready"]:
            current = head["position"]
            if event.target < current:
                return "obsolete_event"
            if event.target == current and event.schema == head["schema"]:
                return "duplicate"
            if event.target == current and not (
                event.full_snapshot and event.schema > head["schema"]
            ):
                return "nonadvancing_event"
        if not event.full_snapshot:
            if not head["ready"] or event.base != head["position"]:
                return "event_gap"
            candidate = copy.deepcopy(head["rows"])
            candidate.update(copy.deepcopy(event.patch))
        else:
            candidate = copy.deepcopy(source)
        # A model check of adapter completeness, NOT an implicit engine guarantee.
        if candidate != source:
            return "incomplete_delta"
        self.projection = {
            "generation": event.generation, "position": event.target,
            "version": head["version"] + 1, "schema": event.schema,
            "ready": True, "rows": candidate,
        }
        return "published"

    def read_after(self, user: str, command_id: str, key: str) -> dict[str, Any]:
        receipt = self.lookup_receipt(user, command_id)
        if receipt.source.generation != self.generation:
            return {"status": "generation_changed", "command": asdict(receipt.source),
                    "current_generation": self.generation}
        head = self.projection
        if not head["ready"] or head["position"] < receipt.source.position:
            return {"status": "projection_pending", "required": receipt.source.position,
                    "available": head["position"]}
        return {"status": "ok", "value": head["rows"][key],
                "source": asdict(self.token(head["position"])),
                "projection_version": head["version"], "semantics": "at_least"}

    def read_as_of_command(self, user: str, command_id: str, key: str) -> dict[str, Any]:
        receipt = self.lookup_receipt(user, command_id)
        state = self.history[(receipt.source.generation, receipt.source.position)]
        assert digest(state) == receipt.after_hash
        return {"status": "ok", "value": state[key], "source": asdict(receipt.source),
                "semantics": "exact_source_position"}

    def read_authority(self, user: str, key: str) -> dict[str, Any]:
        self.authorize(user)
        # Read saved history, not the command's submitted text or response echo.
        state = self.history[(self.generation, self.position)]
        return {"value": state[key], "source": asdict(self.token()),
                "path": "saved_authority"}

    def restore(self, user: str, revision_source: tuple[int, int]) -> None:
        self.authorize(user)
        restored = copy.deepcopy(self.history[revision_source])
        self.generation += 1
        self.position = 0
        self.rows = restored
        self.history[(self.generation, 0)] = copy.deepcopy(restored)
        self.projection = {
            "generation": self.generation, "position": None,
            "version": self.projection["version"] + 1,
            "schema": self.desired_schema, "ready": False, "rows": {},
        }
        # Old receipts remain scoped to their old generation; old jobs may arrive.

    def read_range(self, user: str, keys: list[str]) -> dict[str, Any]:
        self.authorize(user)
        head = self.projection
        if not head["ready"] or head["generation"] != self.generation:
            return {"status": "projection_pending"}
        cells = {}
        for key in keys:
            raw = head["rows"].get(key)
            if isinstance(raw, str) and raw.startswith("="):
                calc = self.calculation or {}
                fresh = (calc.get("generation"), calc.get("position")) == (
                    head["generation"], head["position"])
                cells[key] = {"formula": raw, "cached_value": calc.get(key),
                              "value": calc.get(key) if fresh else None,
                              "calculation_status": "fresh" if fresh else "stale",
                              "calculation_source": {"generation": calc.get("generation"),
                                                     "position": calc.get("position")},
                              "calculation_revision": calc.get("revision")}
            else:
                cells[key] = {"formula": None, "value": raw, "input": raw}
        return {"status": "ok", "source": asdict(self.token(head["position"])),
                "cells": cells}

    def publish_calculation(self, generation: int, position: int, d2: int) -> str:
        head = self.projection
        if generation != self.generation:
            return "stale_generation"
        if not head["ready"] or position != head["position"]:
            return "calculation_source_mismatch"
        source = self.history[(generation, position)]
        # Arithmetic of this teaching fixture only; NOT a spreadsheet evaluator.
        if source["D2"] != "=SUM(B2:B3)" or d2 != source["B2"] + source["B3"]:
            return "invalid_model_result"
        self.calculation = {"generation": generation, "position": position,
                            "revision": (self.calculation or {}).get("revision", 0) + 1,
                            "engine": "model-only", "D2": d2}
        return "published"


USER = "user-model"


def replace_15_with_30(model: Model, command_id: str = "cmd-42") -> Receipt:
    return model.execute(USER, command_id, 3, {"p17": "Срок 30 дней"},
                         {"p17": "Срок 15 дней"})


def expect_error(code: str, operation) -> None:
    try:
        operation()
    except ContractError as exc:
        assert str(exc) == code, (str(exc), code)
    else:
        raise AssertionError(f"Expected {code}")


def test_01_lost_reply_retry_returns_same_receipt() -> None:
    model = Model()
    committed_but_reply_lost = replace_15_with_30(model)
    repeated = replace_15_with_30(model)
    assert repeated == committed_but_reply_lost
    assert model.position == 42 and len(model.events) == 1 and len(model.receipts) == 1


def test_02_reused_id_with_different_payload_is_conflict() -> None:
    model = Model()
    replace_15_with_30(model)
    expect_error("idempotency_key_payload_conflict", lambda: model.execute(
        USER, "cmd-42", 3, {"p17": "Срок 45 дней"}, {"p17": "Срок 15 дней"}))
    assert model.position == 42 and model.rows["p17"] == "Срок 30 дней"


def test_03_duplicate_event_is_noop() -> None:
    model = Model()
    replace_15_with_30(model)
    event = model.events[-1]
    assert model.publish(event) == "published"
    before = copy.deepcopy(model.projection)
    assert model.publish(event) == "duplicate"
    assert model.projection == before


def two_edits_without_projection() -> Model:
    model = Model()
    replace_15_with_30(model)
    model.execute(USER, "cmd-43", 3, {"p17": "Срок 45 дней"}, {"p17": "Срок 30 дней"})
    return model


def test_04_partial_event_gap_rejected_without_payload_change() -> None:
    model = two_edits_without_projection()
    before = copy.deepcopy(model.projection)
    assert model.publish(model.events[-1]) == "event_gap"
    assert model.projection == before


def test_05_complete_snapshot_can_cover_event_gap() -> None:
    model = two_edits_without_projection()
    assert model.publish(model.full_event(43)) == "published"
    assert model.projection["position"] == 43
    assert model.projection["rows"]["p17"] == "Срок 45 дней"


def test_06_old_generation_job_cannot_mutate_payload_or_head() -> None:
    model = Model()
    replace_15_with_30(model)
    stale = model.events[-1]
    model.restore(USER, (3, 41))
    assert model.publish(model.full_event(0)) == "published"
    before = copy.deepcopy(model.projection)
    assert model.publish(stale) == "stale_generation"
    assert model.projection == before and model.projection["rows"]["p17"] == "Срок 15 дней"


def test_07_schema_rebuild_at_same_source_position() -> None:
    model = Model()
    model.desired_schema = 2
    assert model.publish(model.full_event(41, schema=2)) == "published"
    assert model.projection["position"] == 41 and model.projection["version"] == 2
    before = copy.deepcopy(model.projection)
    assert model.publish(model.full_event(41, schema=1)) == "obsolete_schema"
    assert model.projection == before


def test_08_read_after_42_projection_41_reports_pending() -> None:
    model = Model()
    replace_15_with_30(model)
    result = model.read_after(USER, "cmd-42", "p17")
    assert result == {"status": "projection_pending", "required": 42, "available": 41}
    assert "value" not in result
    assert model.read_authority(USER, "p17")["value"] == "Срок 30 дней"


def test_09_catchup_reads_saved_30_with_source_42() -> None:
    model = Model()
    replace_15_with_30(model)
    assert model.publish(model.events[-1]) == "published"
    result = model.read_after(USER, "cmd-42", "p17")
    assert result["status"] == "ok" and result["value"] == "Срок 30 дней"
    assert result["source"]["position"] == 42 and result["source"]["generation"] == 3


def test_10_later_overwrite_distinguishes_latest_from_command_state() -> None:
    model = two_edits_without_projection()
    assert model.publish(model.full_event(43)) == "published"
    latest = model.read_after(USER, "cmd-42", "p17")
    exact = model.read_as_of_command(USER, "cmd-42", "p17")
    assert latest["value"] == "Срок 45 дней" and latest["source"]["position"] == 43
    assert exact["value"] == "Срок 30 дней" and exact["source"]["position"] == 42


def test_11_restore_invalidates_old_token_but_preserves_retry_receipt() -> None:
    model = Model()
    original = replace_15_with_30(model)
    model.restore(USER, (3, 41))
    assert replace_15_with_30(model) == original
    assert model.generation == 4 and model.position == 0
    assert model.read_after(USER, "cmd-42", "p17")["status"] == "generation_changed"
    assert model.read_authority(USER, "p17")["value"] == "Срок 15 дней"
    assert model.read_as_of_command(USER, "cmd-42", "p17")["value"] == "Срок 30 дней"
    expect_error("generation_changed", lambda: replace_15_with_30(model, "new-old-generation-id"))


def modified_book() -> Model:
    model = Model("book")
    model.execute(USER, "book-cmd-42", 3, {"B2": 15}, {"B2": 12})
    assert model.publish(model.events[-1]) == "published"
    return model


def test_12_stale_20_is_not_returned_as_current_formula_value() -> None:
    model = modified_book()
    cells = model.read_range(USER, ["B2", "B3", "D2"])["cells"]
    assert cells["B2"]["value"] == 15 and cells["B3"]["value"] == 8
    assert cells["D2"]["formula"] == "=SUM(B2:B3)"
    assert cells["D2"]["cached_value"] == 20 and cells["D2"]["value"] is None
    assert cells["D2"]["calculation_status"] == "stale"
    assert cells["D2"]["calculation_source"]["position"] == 41


def test_13_calculation_for_source_42_publishes_fresh_23() -> None:
    model = modified_book()
    assert model.publish_calculation(3, 42, 23) == "published"
    d2 = model.read_range(USER, ["D2"])["cells"]["D2"]
    assert d2["formula"] == "=SUM(B2:B3)" and d2["value"] == 23
    assert d2["calculation_status"] == "fresh" and d2["calculation_revision"] == 2
    assert d2["calculation_source"]["position"] == 42


def test_14_revocation_denies_new_reads_and_receipt_lookup() -> None:
    model = modified_book()
    assert model.publish_calculation(3, 42, 23) == "published"
    assert model.read_range(USER, ["D2"])["cells"]["D2"]["value"] == 23
    model.allowed.remove(USER)
    for operation in [
        lambda: model.read_range(USER, ["D2"]),
        lambda: model.lookup_receipt(USER, "book-cmd-42"),
        lambda: model.read_after(USER, "book-cmd-42", "B2"),
        lambda: model.read_as_of_command(USER, "book-cmd-42", "B2"),
        lambda: model.read_authority(USER, "B2"),
    ]:
        expect_error("access_denied", operation)


def test_15_future_source_and_wrong_calculation_source_rejected() -> None:
    model = modified_book()
    before = copy.deepcopy(model.projection)
    assert model.publish(Event(3, 42, 99, {"B2": 999})) == "future_source"
    assert model.projection == before
    old_calc = copy.deepcopy(model.calculation)
    assert model.publish_calculation(3, 41, 20) == "calculation_source_mismatch"
    assert model.calculation == old_calc
    model.restore(USER, (3, 41))
    assert model.publish_calculation(3, 42, 23) == "stale_generation"
    assert model.calculation == old_calc


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=Path(__file__).with_name("model_results.json"))
    args = parser.parse_args()
    tests = sorted((name, value) for name, value in globals().items()
                   if name.startswith("test_") and callable(value))
    cases = []
    for name, test in tests:
        try:
            test()
            cases.append({"scenario": name, "status": "passed"})
        except Exception as exc:
            cases.append({"scenario": name, "status": "failed",
                          "error": f"{type(exc).__name__}: {exc}"})
    result = {
        "classification": "executable_contract_model_only",
        "not_evidence_of": ["SQL isolation", "Yjs integration", "Univer integration",
                            "durable storage", "load performance", "production ACL implementation"],
        "run_at_utc": datetime.now(timezone.utc).isoformat(),
        "python": sys.version.split()[0], "scenario_count": len(cases),
        "passed": sum(case["status"] == "passed" for case in cases),
        "failed": sum(case["status"] == "failed" for case in cases),
        "cases": cases,
    }
    args.output.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"output": str(args.output.resolve()),
                      "passed": result["passed"], "failed": result["failed"],
                      "classification": result["classification"]}, ensure_ascii=False))
    return 1 if result["failed"] else 0


if __name__ == "__main__":
    raise SystemExit(main())
