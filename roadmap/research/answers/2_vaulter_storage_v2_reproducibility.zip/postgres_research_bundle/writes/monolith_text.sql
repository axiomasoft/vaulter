\set ON_ERROR_STOP on
\timing on
-- Measures storage work only, not command receipts, outbox or a spreadsheet engine.
BEGIN;
SELECT source_seq FROM vbench.monolith WHERE organization_id=1 AND document_id=1 FOR UPDATE;
DO $guard$ BEGIN
  IF (SELECT generation=1 AND source_seq=1 FROM vbench.monolith WHERE organization_id=1 AND document_id=1) IS DISTINCT FROM TRUE THEN
    RAISE EXCEPTION 'This microbenchmark requires a pristine generation=1/source_seq=1 fixture; reload before retry.';
  END IF;
END $guard$;
EXPLAIN (ANALYZE, BUFFERS, WAL, SERIALIZE TEXT, TIMING OFF, FORMAT JSON)
UPDATE vbench.monolith SET body=jsonb_set(body,'{content,18,content}', '[{"type":"text","text":"Срок 30 дней"}]'::jsonb,false),source_seq=2
WHERE organization_id=1 AND document_id=1 AND generation=1 AND source_seq=1
RETURNING generation,source_seq;
COMMIT;
