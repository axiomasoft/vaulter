\set ON_ERROR_STOP on
\timing on
-- Run after parts_text.sql; makes a new whole snapshot at source_seq=2.
BEGIN;
SELECT source_seq FROM vbench.part_head WHERE organization_id=1 AND document_id=1 FOR SHARE;
DO $guard$ BEGIN
  IF (SELECT generation=1 AND source_seq=2 FROM vbench.part_head WHERE organization_id=1 AND document_id=1) IS DISTINCT FROM TRUE THEN
    RAISE EXCEPTION 'Snapshot benchmark requires the corresponding parts mutation at source_seq=2.';
  END IF;
END $guard$;
EXPLAIN (ANALYZE, BUFFERS, WAL, SERIALIZE TEXT, TIMING OFF, FORMAT JSON)
INSERT INTO vbench.part_snapshot
SELECT h.organization_id,h.document_id,h.generation,h.source_seq,
       jsonb_build_object('type','doc','content',jsonb_agg(p.node ORDER BY p.order_key))
FROM vbench.part_head h JOIN vbench.block_part p USING (organization_id,document_id,generation)
WHERE h.organization_id=1 AND h.document_id=1 AND h.generation=1 AND h.source_seq=2
GROUP BY h.organization_id,h.document_id,h.generation,h.source_seq;
COMMIT;
