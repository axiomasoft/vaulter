\set ON_ERROR_STOP on
\timing on
-- Run after parts_cell.sql; the D2 cache remains explicitly computed for source_seq=1.
BEGIN;
SELECT source_seq FROM vbench.part_head WHERE organization_id=1 AND document_id=2 FOR SHARE;
DO $guard$ BEGIN
  IF (SELECT generation=1 AND source_seq=2 FROM vbench.part_head WHERE organization_id=1 AND document_id=2) IS DISTINCT FROM TRUE THEN
    RAISE EXCEPTION 'Snapshot benchmark requires the corresponding parts mutation at source_seq=2.';
  END IF;
END $guard$;
EXPLAIN (ANALYZE, BUFFERS, WAL, SERIALIZE TEXT, TIMING OFF, FORMAT JSON)
INSERT INTO vbench.part_snapshot
SELECT h.organization_id,h.document_id,h.generation,h.source_seq,
  jsonb_build_object('format','vaulter-storage-benchmark-fixture-1','sheets',jsonb_build_object('s1',
    jsonb_build_object('name','Учебный лист','rowCount',10000,'columnCount',1000,
      'cells',jsonb_object_agg(p.row_no::text||':'||p.col_no::text,p.cell))))
FROM vbench.part_head h JOIN vbench.cell_part p USING (organization_id,document_id,generation)
WHERE h.organization_id=1 AND h.document_id=2 AND h.generation=1 AND h.source_seq=2 AND p.sheet_id='s1'
GROUP BY h.organization_id,h.document_id,h.generation,h.source_seq;
COMMIT;
