\set ON_ERROR_STOP on
\timing on
-- A known small delta; a full extraction/rebuild has a separate script.
-- The D2 cache is deliberately NOT recalculated. Its calc_source_seq remains 1.
BEGIN;
SELECT source_seq FROM vbench.monolith WHERE organization_id=1 AND document_id=2 FOR UPDATE;
DO $guard$ BEGIN
  IF (SELECT generation=1 AND source_seq=1 FROM vbench.monolith WHERE organization_id=1 AND document_id=2) IS DISTINCT FROM TRUE THEN
    RAISE EXCEPTION 'This microbenchmark requires a pristine generation=1/source_seq=1 fixture; reload before retry.';
  END IF;
END $guard$;
SELECT source_seq FROM vbench.projection_head WHERE organization_id=1 AND document_id=2 FOR UPDATE;
DO $guard$ BEGIN
  IF (SELECT generation=1 AND source_seq=1 AND build_id=1 FROM vbench.projection_head WHERE organization_id=1 AND document_id=2) IS DISTINCT FROM TRUE THEN
    RAISE EXCEPTION 'This microbenchmark requires a pristine generation=1/source_seq=1 fixture; reload before retry.';
  END IF;
END $guard$;
EXPLAIN (ANALYZE, BUFFERS, WAL, SERIALIZE TEXT, TIMING OFF, FORMAT JSON)
UPDATE vbench.monolith SET body=jsonb_set(body,'{sheets,s1,cells,2:2,v}', '15'::jsonb,false),source_seq=2
WHERE organization_id=1 AND document_id=2 AND generation=1 AND source_seq=1
RETURNING generation,source_seq;
EXPLAIN (ANALYZE, BUFFERS, WAL, SERIALIZE TEXT, TIMING OFF, FORMAT JSON)
UPDATE vbench.cell_projection SET cell=jsonb_set(cell,'{v}','15'::jsonb,false)
WHERE organization_id=1 AND document_id=2 AND generation=1 AND build_id=1 AND sheet_id='s1' AND row_no=2 AND col_no=2;
EXPLAIN (ANALYZE, BUFFERS, WAL, SERIALIZE TEXT, TIMING OFF, FORMAT JSON)
UPDATE vbench.projection_head SET source_seq=2
WHERE organization_id=1 AND document_id=2 AND generation=1 AND source_seq=1;
COMMIT;
