\set ON_ERROR_STOP on
\timing on
-- Full extraction into build 2 plus publication. Run only on a pristine fixture.
-- This isolated benchmark uses a long source lock to simplify reproducibility.
-- Production should compute staging outside the short CAS publication transaction.
BEGIN;
DO $guard$ BEGIN
  IF (SELECT count(*) FROM vbench.monolith WHERE organization_id=1 AND document_id IN (1,2) AND generation=1 AND source_seq=1) <> 2 THEN
    RAISE EXCEPTION 'Full rebuild benchmark requires both pristine source snapshots.';
  END IF;
END $guard$;
SELECT source_seq FROM vbench.monolith WHERE organization_id=1 AND document_id IN (1,2) ORDER BY document_id FOR SHARE;
SELECT source_seq FROM vbench.projection_head WHERE organization_id=1 AND document_id=1 FOR UPDATE;
DO $guard$ BEGIN
  IF (SELECT generation=1 AND source_seq=1 AND build_id=1 FROM vbench.projection_head WHERE organization_id=1 AND document_id=1) IS DISTINCT FROM TRUE THEN
    RAISE EXCEPTION 'This microbenchmark requires a pristine generation=1/source_seq=1 fixture; reload before retry.';
  END IF;
END $guard$;
SELECT source_seq FROM vbench.projection_head WHERE organization_id=1 AND document_id=2 FOR UPDATE;
DO $guard$ BEGIN
  IF (SELECT generation=1 AND source_seq=1 AND build_id=1 FROM vbench.projection_head WHERE organization_id=1 AND document_id=2) IS DISTINCT FROM TRUE THEN
    RAISE EXCEPTION 'This microbenchmark requires a pristine generation=1/source_seq=1 fixture; reload before retry.';
  END IF;
END $guard$;
EXPLAIN (ANALYZE, BUFFERS, WAL, SERIALIZE TEXT, TIMING OFF, FORMAT JSON)
INSERT INTO vbench.block_projection
SELECT 1,1,1,2,e.node->'attrs'->>'blockId',e.ord*1024,e.node
FROM vbench.monolith m
CROSS JOIN LATERAL jsonb_array_elements(m.body->'content') WITH ORDINALITY e(node,ord)
WHERE m.organization_id=1 AND m.document_id=1 AND m.generation=1 AND m.source_seq=1;
EXPLAIN (ANALYZE, BUFFERS, WAL, SERIALIZE TEXT, TIMING OFF, FORMAT JSON)
INSERT INTO vbench.cell_projection
SELECT 1,2,1,2,'s1',split_part(e.key,':',1)::integer,split_part(e.key,':',2)::integer,e.value
FROM vbench.monolith m
CROSS JOIN LATERAL jsonb_each(m.body#>'{sheets,s1,cells}') e
WHERE m.organization_id=1 AND m.document_id=2 AND m.generation=1 AND m.source_seq=1;
EXPLAIN (ANALYZE, BUFFERS, WAL, SERIALIZE TEXT, TIMING OFF, FORMAT JSON)
UPDATE vbench.projection_head h SET build_id=2
WHERE h.organization_id=1 AND h.document_id IN (1,2) AND h.generation=1 AND h.source_seq=1 AND h.build_id=1
  AND EXISTS (SELECT 1 FROM vbench.monolith m WHERE m.organization_id=h.organization_id
              AND m.document_id=h.document_id AND m.generation=h.generation AND m.source_seq=h.source_seq);
COMMIT;
-- Previous build 1 is retained. Report its disk/WAL/vacuum/GC costs separately.
