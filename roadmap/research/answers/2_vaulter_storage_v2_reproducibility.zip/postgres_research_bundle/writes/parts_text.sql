\set ON_ERROR_STOP on
\timing on
-- Authoritative-part microbenchmark; engine semantics and durable command receipts are outside this toy schema.
BEGIN;
SELECT source_seq FROM vbench.part_head WHERE organization_id=1 AND document_id=1 FOR UPDATE;
DO $guard$ BEGIN
  IF (SELECT generation=1 AND source_seq=1 FROM vbench.part_head WHERE organization_id=1 AND document_id=1) IS DISTINCT FROM TRUE THEN
    RAISE EXCEPTION 'This microbenchmark requires a pristine generation=1/source_seq=1 fixture; reload before retry.';
  END IF;
END $guard$;
EXPLAIN (ANALYZE, BUFFERS, WAL, SERIALIZE TEXT, TIMING OFF, FORMAT JSON)
UPDATE vbench.block_part SET node=jsonb_set(node,'{content}','[{"type":"text","text":"Срок 30 дней"}]'::jsonb,false)
WHERE organization_id=1 AND document_id=1 AND generation=1 AND block_id='p17';
EXPLAIN (ANALYZE, BUFFERS, WAL, SERIALIZE TEXT, TIMING OFF, FORMAT JSON)
UPDATE vbench.part_head SET source_seq=2
WHERE organization_id=1 AND document_id=1 AND generation=1 AND source_seq=1;
COMMIT;
