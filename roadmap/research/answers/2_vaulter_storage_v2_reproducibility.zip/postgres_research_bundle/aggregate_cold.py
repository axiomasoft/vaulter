#!/usr/bin/env python3
"""Aggregate independently prepared cold trial JSON files; never mix cache states."""
import collections
import json
import math
import sys
from pathlib import Path

groups = collections.defaultdict(list)
for argument in sys.argv[1:]:
    data = json.loads(Path(argument).read_text())
    if data.get("status") != "MEASURED":
        continue
    state = data["cache_state_claimed_by_operator"]
    if state == "warm":
        raise SystemExit(f"Refusing warm input: {argument}")
    for case in data["cases"]:
        if case["sample_count"] != 1:
            raise SystemExit(f"Expected one independently prepared cold sample: {argument}")
        key = (case["case"], state, data["postgres_version"],
               json.dumps(data["fixture_manifest"]["files"], sort_keys=True))
        groups[key].extend(case["samples_ms"])
result = []
for key, samples in groups.items():
    values = sorted(samples)
    result.append({"case": key[0], "cache_state": key[1], "postgres_version": key[2],
                   "sample_count": len(values),
                   "p95_ms": values[math.ceil(len(values) * .95) - 1] if len(values) >= 20 else None,
                   "samples_ms": values, "operator_cache_preparation_is_not_independently_verified": True})
print(json.dumps({"groups": result, "status": "MEASURED" if result else "NOT_RUN"}, ensure_ascii=False, indent=2))
