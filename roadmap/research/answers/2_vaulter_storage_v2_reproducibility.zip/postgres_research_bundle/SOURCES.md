# Первичные источники

Проверены 20.11.2026. Ссылки на документацию фиксируют major PostgreSQL 18,
а не плавающий `/current`. Doxygen — опубликованный текущий исходный код;
его нельзя объявлять конкретным release tag 18.0 без отдельной проверки.

1. PostgreSQL 18, §66.2 TOAST, §66.2.1 Out-of-Line, On-Disk TOAST Storage.
   https://www.postgresql.org/docs/18/storage-toast.html
   TOAST, компрессия, chunks; отличие substring text/bytea от общего detoast;
   неизменённые внешние поля обычно сохраняются без повторной записи TOAST.

2. PostgreSQL 18, §8.14.2 Designing JSON Documents, §8.14.4 jsonb Indexing.
   https://www.postgresql.org/docs/18/datatype-json.html
   JSONB не требует повторного разбора текста; UPDATE блокирует всю строку;
   GIN ищет ключи/значения среди документов и имеет ограниченный набор операторов.

3. PostgreSQL current source, src/include/utils/jsonb.h, DatumGetJsonbP.
   https://doxygen.postgresql.org/jsonb_8h.html
   PG_GETARG_JSONB_P вызывает PG_DETOAST_DATUM.

4. PostgreSQL current source, src/backend/utils/adt/jsonfuncs.c,
   get_jsonb_path_all, jsonb_object_field_text, jsonb_set.
   https://doxygen.postgresql.org/jsonfuncs_8c_source.html
   Извлечение получает detoasted Jsonb; jsonb_set строит возвращаемое Jsonb.

5. PostgreSQL current source, src/backend/access/common/detoast.c,
   detoast_attr, toast_fetch_datum.
   https://doxygen.postgresql.org/detoast_8c.html
   Путь внешнего datum загружает все chunks; сжатый datum затем распаковывается.

6. PostgreSQL 18, §11.3 Multicolumn Indexes.
   https://www.postgresql.org/docs/18/indexes-multicolumn.html
   Граница левых равенств/первого диапазона и возможный skip scan.

7. PostgreSQL 18, §11.9 Index-Only Scans and Covering Indexes.
   https://www.postgresql.org/docs/18/indexes-index-only-scans.html
   GIN не умеет index-only; visibility map; цена и ограничения INCLUDE.

8. PostgreSQL 18, §11.7 Indexes on Expressions.
   https://www.postgresql.org/docs/18/indexes-expressional.html
   Выражения вычисляются при вставках и non-HOT обновлениях, а не при поиске.

9. PostgreSQL 18, EXPLAIN, параметры ANALYZE, BUFFERS, SERIALIZE, WAL, MEMORY.
   https://www.postgresql.org/docs/18/sql-explain.html
   SERIALIZE по умолчанию NONE; MEMORY относится к планированию; сеть не измеряется.

10. PostgreSQL 18, §14.1 Using EXPLAIN, §14.1.3 Caveats.
    https://www.postgresql.org/docs/18/using-explain.html
    Оценки плана не равны реальному времени; rows — выданные, а не все просмотренные.

11. PostgreSQL 18, §27.2 Cumulative Statistics System,
    §27.2.2, §27.2.13 pg_stat_io, §27.2.21 pg_statio_all_tables, §27.2.26.
    https://www.postgresql.org/docs/18/monitoring-stats.html
    Счётчики запаздывают; кэш ОС не отличается от физического диска;
    есть отдельные heap/index/TOAST показатели и I/O конкретного backend.

12. PostgreSQL 18, DISCARD.
    https://www.postgresql.org/docs/18/sql-discard.html
    Сбрасывается состояние сессии, не shared buffers всего сервера.

13. PostgreSQL 18, F.30 pg_prewarm.
    https://www.postgresql.org/docs/18/pgprewarm.html
    Кэши PostgreSQL и ОС различаются; autoprewarm может загрузить данные после рестарта.

14. PostgreSQL 18, F.32 pg_stat_statements.
    https://www.postgresql.org/docs/18/pgstatstatements.html
    Агрегаты вызовов/времени/блоков/WAL не заменяют распределение сырых задержек.

15. PostgreSQL 18, §66.7 Heap-Only Tuples.
    https://www.postgresql.org/docs/18/storage-hot.html
    MVCC создаёт новые версии строк; HOT применим только при выполнении условий.

16. PostgreSQL 18, §28.5 WAL Configuration.
    https://www.postgresql.org/docs/18/wal-configuration.html
    Checkpoint/FPI и настройки WAL влияют на измеряемую цену обновлений.

17. Linux Kernel documentation, Documentation for /proc/sys/vm/, drop_caches.
    https://docs.kernel.org/admin-guide/sysctl/vm.html#drop-caches
    Очистка clean page cache, предварительный sync и ограничение тестовой средой.
