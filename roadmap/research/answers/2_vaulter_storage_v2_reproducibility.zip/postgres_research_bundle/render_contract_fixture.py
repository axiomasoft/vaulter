#!/usr/bin/env python3
"""Render the unchanged ProseMirror fixture as an explicit 100-page reference PDF.

Use the primary runtime Python when available. Requires reportlab and pypdf.
No database performance is measured by this script.
"""
import argparse
import hashlib
import html
import json
import os
import platform
import re
from pathlib import Path

import reportlab
import pypdf
from pypdf import PdfReader
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.pdfgen.canvas import Canvas
from reportlab.platypus import Paragraph


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def normalized(text):
    return re.sub(r"\s+", " ", text).strip()


def inline_markup(node):
    result = []
    for item in node.get("content", []):
        if item.get("type") != "text":
            raise ValueError("This reference renderer expects text inline nodes in this fixture.")
        value = html.escape(item.get("text", ""))
        for mark in item.get("marks", []):
            kind = mark.get("type")
            if kind == "bold":
                value = "<b>" + value + "</b>"
            elif kind == "italic":
                value = "<i>" + value + "</i>"
            elif kind == "link":
                href = html.escape(mark.get("attrs", {}).get("href", ""), quote=True)
                value = '<link href="' + href + '" color="#285b7a"><u>' + value + "</u></link>"
            else:
                raise ValueError(f"Unsupported mark in this fixture: {kind}")
        result.append(value)
    return "".join(result)


def find_font_dir(requested):
    candidates = []
    if requested:
        candidates.append(requested)
    runtime_root = os.environ.get("CODEX_PRIMARY_RUNTIME_ROOT")
    if runtime_root:
        candidates.append(Path(runtime_root) / "dependencies/native/libreoffice-headless/libreoffice/share/fonts/truetype")
    candidates.append(Path("/usr/share/fonts/truetype/liberation"))
    for candidate in candidates:
        if all((candidate / f"LiberationSerif-{style}.ttf").is_file()
               for style in ["Regular", "Bold", "Italic", "BoldItalic"]):
            return candidate
    raise RuntimeError("LiberationSerif TrueType fonts with Cyrillic coverage are required; use --font-dir.")


def main():
    base = Path(__file__).parent
    parser = argparse.ArgumentParser()
    parser.add_argument("--source", type=Path, default=base / "fixtures" / "contract.json")
    parser.add_argument("--output", type=Path, default=base / "fixtures" / "contract_100_pages.pdf")
    parser.add_argument("--manifest", type=Path, default=base / "fixtures" / "pdf_manifest.json")
    parser.add_argument("--font-dir", type=Path)
    args = parser.parse_args()
    before_hash = digest(args.source)
    fixture_manifest = json.loads((args.source.parent / "fixture_manifest.json").read_text())
    expected = next(f["sha256"] for f in fixture_manifest["files"] if f["path"] == args.source.name)
    if before_hash != expected:
        raise ValueError("The source JSON does not match its original fixture manifest.")
    document = json.loads(args.source.read_text())
    groups = []
    for node in document["content"]:
        if node["type"] == "heading":
            groups.append([node])
        elif node["type"] == "paragraph" and groups:
            groups[-1].append(node)
        else:
            raise ValueError("Unexpected fixture structure.")
    if len(groups) != 100 or any(len(group) != 11 for group in groups):
        raise ValueError("Expected exactly 100 groups, each with 1 heading and 10 paragraphs.")

    fonts = find_font_dir(args.font_dir)
    font_records = []
    for font_style, font_name in [("Regular", "FixtureSerif"), ("Bold", "FixtureSerifBold"),
                                  ("Italic", "FixtureSerifItalic"), ("BoldItalic", "FixtureSerifBoldItalic")]:
        path = fonts / f"LiberationSerif-{font_style}.ttf"
        pdfmetrics.registerFont(TTFont(font_name, str(path)))
        font_records.append({"filename": path.name, "sha256": digest(path), "bytes": path.stat().st_size})
    pdfmetrics.registerFontFamily("FixtureSerif", normal="FixtureSerif", bold="FixtureSerifBold",
                                  italic="FixtureSerifItalic", boldItalic="FixtureSerifBoldItalic")
    width, height = A4
    margin_left = margin_right = 42.0
    body_width = width - margin_left - margin_right
    body_top = height - 92.0
    body_bottom = 42.0
    body_style = ParagraphStyle("fixture-body", fontName="FixtureSerif", fontSize=11.0,
                                leading=12.8, textColor=colors.HexColor("#18232f"),
                                spaceAfter=4.0, allowWidows=0, allowOrphans=0)
    heading_style = ParagraphStyle("fixture-heading", fontName="FixtureSerifBold", fontSize=14.5,
                                   leading=17.5, textColor=colors.HexColor("#153e55"))

    layouts = []
    page_records = []
    for page_number, group in enumerate(groups, start=1):
        heading = Paragraph(inline_markup(group[0]), heading_style)
        heading_width, heading_height = heading.wrap(body_width, 10000)
        if heading_height > 19.0:
            raise ValueError(f"Heading overflow on page {page_number}")
        paragraphs = []
        used_height = 0.0
        for node in group[1:]:
            paragraph = Paragraph(inline_markup(node), body_style)
            wrap_width, wrap_height = paragraph.wrap(body_width, 10000)
            paragraphs.append((node, paragraph, wrap_height))
            used_height += wrap_height + body_style.spaceAfter
        clearance = body_top - used_height - body_bottom
        if clearance < 0:
            raise ValueError(f"Body overflow on page {page_number}: {-clearance:.2f} pt")
        layouts.append((heading, heading_height, paragraphs))
        page_records.append({"page": page_number, "heading_id": group[0]["attrs"]["blockId"],
                             "block_ids": [node["attrs"]["blockId"] for node in group],
                             "body_height_pt": used_height, "bottom_clearance_pt": clearance})

    args.output.parent.mkdir(parents=True, exist_ok=True)
    canvas = Canvas(str(args.output), pagesize=A4, pageCompression=1, invariant=1)
    canvas.setTitle("Синтетический нагрузочный договор: 100 страниц")
    canvas.setAuthor("Vaulter storage benchmark fixture")
    canvas.setSubject("Синтетический эталон пагинации. Не юридический документ. Source SHA-256: " + before_hash)
    for page_number, (heading, heading_height, paragraphs) in enumerate(layouts, start=1):
        canvas.setFillColor(colors.HexColor("#153e55"))
        canvas.setFont("FixtureSerifBold", 9.2)
        canvas.drawString(margin_left, height - 25,
                          "СИНТЕТИЧЕСКИЙ НАГРУЗОЧНЫЙ ДОГОВОР")
        canvas.setFillColor(colors.HexColor("#667788"))
        canvas.setFont("FixtureSerif", 8.0)
        canvas.drawString(margin_left, height - 38,
                          "Тестовый набор для хранения документов. Не является юридическим договором.")
        canvas.setStrokeColor(colors.HexColor("#c4d3dc"))
        canvas.setLineWidth(0.55)
        canvas.line(margin_left, height - 46, width - margin_right, height - 46)
        heading.drawOn(canvas, margin_left, height - 72)
        canvas.setFillColor(colors.HexColor("#8695a0"))
        canvas.setFont("FixtureSerif", 6.7)
        canvas.drawRightString(margin_left - 6, height - 65, page_records[page_number-1]["heading_id"])
        y = body_top
        for node, paragraph, paragraph_height in paragraphs:
            canvas.setFillColor(colors.HexColor("#8695a0"))
            canvas.setFont("FixtureSerif", 6.7)
            canvas.drawRightString(margin_left - 6, y - 9.0, node["attrs"]["blockId"])
            paragraph.drawOn(canvas, margin_left, y - paragraph_height)
            y -= paragraph_height + body_style.spaceAfter
        canvas.setStrokeColor(colors.HexColor("#c4d3dc"))
        canvas.line(margin_left, 34, width - margin_right, 34)
        canvas.setFillColor(colors.HexColor("#667788"))
        canvas.setFont("FixtureSerif", 7.5)
        canvas.drawString(margin_left, 21, "Источник JSON: SHA-256 " + before_hash[:24])
        canvas.drawRightString(width - margin_right, 21, f"Страница {page_number} / 100")
        canvas.showPage()  # Exactly one source group per physical page.
    canvas.save()

    reader = PdfReader(str(args.output))
    if len(reader.pages) != 100:
        raise AssertionError(f"Expected 100 physical pages, got {len(reader.pages)}")
    for page_number, (pdf_page, group) in enumerate(zip(reader.pages, groups), start=1):
        extracted = normalized(pdf_page.extract_text())
        for node in group:
            source_text = normalized("".join(item["text"] for item in node.get("content", [])))
            if source_text not in extracted:
                raise AssertionError(f"Missing source text on page {page_number}, block {node['attrs']['blockId']}")
    links = sum(1 for page in reader.pages for ref in page.get("/Annots", [])
                if ref.get_object().get("/Subtype") == "/Link")
    if digest(args.source) != before_hash:
        raise AssertionError("Source JSON was modified")
    manifest = {
        "renderer_version": 1, "synthetic_fixture_not_a_legal_document": True,
        "source_json": {"path": args.source.name, "bytes": args.source.stat().st_size, "sha256": before_hash},
        "pdf": {"path": args.output.name, "bytes": args.output.stat().st_size,
                "sha256": digest(args.output), "verified_page_count": len(reader.pages)},
        "software": {"python": platform.python_version(), "reportlab": reportlab.Version, "pypdf": pypdf.__version__},
        "layout": {"paper": "A4 portrait", "page_width_pt": width, "page_height_pt": height,
                   "left_margin_pt": margin_left, "right_margin_pt": margin_right,
                   "body_top_pt_from_bottom": body_top, "body_bottom_pt_from_bottom": body_bottom,
                   "body_font_family": "Liberation Serif", "body_font_size_pt": 11.0,
                   "body_leading_pt": 12.8, "paragraph_gap_pt": 4.0,
                   "explicit_page_break_after_each_source_group": True,
                   "reportlab_invariant_mode": True},
        "font_files": font_records,
        "validation": {"all_page_heights_fit": True,
                       "min_bottom_clearance_pt": min(item["bottom_clearance_pt"] for item in page_records),
                       "all_1100_source_nodes_found_in_extracted_pages": True,
                       "link_annotation_count": links, "source_json_unchanged": True,
                       "visual_review_pages": [1, 2, 50, 100],
                       "visual_review_status": "PENDING_EXTERNAL_RENDER_REVIEW"},
        "page_mapping": page_records,
    }
    args.manifest.write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"pdf": manifest["pdf"], "validation": manifest["validation"], "manifest": str(args.manifest)}, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
