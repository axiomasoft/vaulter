// Executed with Node v24.22.3, @ironcalc/nodejs and @ironcalc/wasm 0.9.1.
// npm install --ignore-scripts @ironcalc/nodejs@0.9.1 @ironcalc/wasm@0.9.1
// node probe.mjs ../ironcalc_probe_results/r2.icalc
import fs from 'node:fs';
import assert from 'node:assert/strict';
import { Model as RawModel, UserModel } from '@ironcalc/nodejs';
import init, { Model as WasmModel } from '@ironcalc/wasm';

const model = RawModel.fromBytes(fs.readFileSync(process.argv[2]));
assert.equal(model.getCellValue(1,2,2), 41);
model.insertRows(0,2,1);
model.evaluate();
assert.equal(model.getCellValue(1,2,2), 41);
assert.equal(model.getCellFormula(1,2,2), '=SUM(Detail!D3:D4)');
const wasmPath = new URL('./node_modules/@ironcalc/wasm/wasm_bg.wasm', import.meta.url);
await init({module_or_path: fs.readFileSync(wasmPath)});
const wm = WasmModel.fromBytes(model.toBytes(), 'en');
const before = wm.getFormattedCellValue(1,2,2);
assert.equal(before, '41.00');
wm.setUserInput(0,4,3, '8');
const after = wm.getFormattedCellValue(1,2,2);
assert.equal(after, '44.00');
const backToNode = RawModel.fromBytes(wm.toBytes());
assert.equal(backToNode.getCellValue(1,2,2), 44);
fs.writeFileSync(new URL('../ironcalc_probe_results/from-node-wasm.icalc', import.meta.url), wm.toBytes());
const um = new UserModel('api');
const result = {
 node:process.version, nativePackage: '0.9.1', wasmPackage:'0.9.1',
 documentType:typeof globalThis.document, windowType:typeof globalThis.window,
 nativeRead:{value:model.getCellValue(1,2,2),formula:model.getCellFormula(1,2,2),type:model.getCellType(1,2,2),format:model.getCellStyle(1,2,2).num_fmt},
 wasmRead:{before,after,formula:wm.getCellContent(1,2,2),type:wm.getCellType(1,2,2)},
 nativeUserModelGetCellValue: typeof um.getCellValue,
 nativeUserModelGetCellFormula: typeof um.getCellFormula,
 wasmGetCellValue:typeof wm.getCellValue,
 wasmGetCellFormula:typeof wm.getCellFormula,
 nativeBackFromWasmValue:backToNode.getCellValue(1,2,2),
 scope:'Node native + WASM without DOM; no browser UI was launched.'
};
fs.writeFileSync(new URL('../ironcalc_probe_results/node-wasm-results.json', import.meta.url), JSON.stringify(result,null,2)+'\n');
console.log(JSON.stringify(result,null,2));
wm.free();
