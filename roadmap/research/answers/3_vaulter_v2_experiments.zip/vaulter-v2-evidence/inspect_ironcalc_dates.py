#!/usr/bin/env python3
"""Portable reimplementation of the historical inline date-cell read diagnostic.
No workbook is modified or saved; this helper was assembled for reproducibility.
"""
import argparse,json
from pathlib import Path
import ironcalc as ic
assert ic.__version__ == '0.9.1'
ap=argparse.ArgumentParser()
ap.add_argument('--input',type=Path,required=True)
ap.add_argument('--output-dir',type=Path,required=True)
ap.add_argument('--json-out',type=Path,required=True)
a=ap.parse_args()
result={}
for mode in ['original','noop','recalc','insert']:
    path=a.input if mode=='original' else a.output_dir/f'{a.input.stem}-{mode}.xlsx'
    m=ic.load_from_xlsx(str(path));shift=1 if mode=='insert' else 0
    result[mode]={f'A{row}':{'value':m.get_cell_value(0,row,1),'formula':m.get_cell_formula(0,row,1),'display':m.get_formatted_cell_value(0,row,1),'format':m.get_cell_style(0,row,1)['num_fmt']} for row in range(5+shift,12+shift)}
a.json_out.parent.mkdir(parents=True,exist_ok=True)
a.json_out.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(result,ensure_ascii=False,indent=2))
