#!/usr/bin/env python3
"""Deterministic engine-neutral 100,000-cell workload. No engine timings are fabricated."""
import argparse
import hashlib
import json
from pathlib import Path


def build(layout):
    stride = 397 if layout == 'sparse' else 1
    sheets, writes, checks_before, checks_after = [], [], [], []
    before_by_sheet, after_by_sheet = [], []
    selected = {0: 0, 2: 1, 4: 127, 6: 1023, 9: 2499}
    for s in range(10):
        name = f'Sheet{s}'
        cells, before, after = [], [], []
        for i in range(2500):
            row = 2 + i * stride
            qty = 1 + i % 7
            price = 1 + (s * 13 + i * 7) % 97
            sku = f'item-{s}-{i}'
            expression = f'=B{row}*C{row}'
            v = qty * price
            changed_price = price + 1 if i < 1000 else price
            w = qty * changed_price
            if s > 0 and i % 25 == 0:
                expression += f'+Sheet{s-1}!D{row}'
                v += before_by_sheet[s-1][i]
                w += after_by_sheet[s-1][i]
            before.append(v)
            after.append(w)
            cells.extend([
                {'row': row, 'col': 1, 'value': sku, 'kind': 'string'},
                {'row': row, 'col': 2, 'value': qty, 'kind': 'number'},
                {'row': row, 'col': 3, 'value': price, 'kind': 'number'},
                {'row': row, 'col': 4, 'formula': expression, 'kind': 'formula', 'expected': v},
            ])
            if i < 1000:
                writes.append({'sheet': name, 'row': row, 'col': 3, 'value': changed_price})
            if selected.get(s) == i:
                checks_before.append({'range': f'{name}!A{row}:D{row}', 'values': [sku, qty, price, v]})
                checks_after.append({'range': f'{name}!A{row}:D{row}', 'values': [sku, qty, changed_price, w]})
        sheets.append({'name': name, 'cells': cells})
        before_by_sheet.append(before)
        after_by_sheet.append(after)
    count = sum(len(s['cells']) for s in sheets)
    assert count == 100000 and len(writes) == 10000
    return {
        'spec_version': 1,
        'layout': layout,
        'indexing': 'sheet by stable name; row and col are one-based',
        'date_system': '1900',
        'locale': 'en-US',
        'timezone': 'UTC',
        'number_format': 'General',
        'filled_cells': count,
        'formula_cells': 25000,
        'cross_sheet_formula_cells': 900,
        'last_row': 2 + 2499 * stride,
        'sheets': sheets,
        'bulk_writes': writes,
        'read_twenty_populated': checks_before,
        'read_twenty_populated_after_bulk': checks_after,
        'read_twenty_contiguous': 'Sheet0!A2:D6',
        'all_formula_values_checksum_before': sum(map(sum, before_by_sheet)),
        'all_formula_values_checksum_after': sum(map(sum, after_by_sheet)),
        'note': 'Load each scenario from the same immutable seed; do not time JSON generation as calculation.',
    }


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--layout', choices=['sparse', 'dense'], default='sparse')
    ap.add_argument('--out', type=Path, required=True)
    args = ap.parse_args()
    workload = build(args.layout)
    raw = json.dumps(workload, ensure_ascii=False, separators=(',', ':')).encode()
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_bytes(raw)
    summary = {k: workload[k] for k in ['spec_version','layout','filled_cells','formula_cells','cross_sheet_formula_cells','last_row','all_formula_values_checksum_before','all_formula_values_checksum_after']}
    summary.update({'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest(), 'engine_benchmarks_run': False})
    print(json.dumps(summary, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
