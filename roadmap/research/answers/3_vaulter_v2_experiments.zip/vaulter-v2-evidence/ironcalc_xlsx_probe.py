#!/usr/bin/env python3
"""Import/export diagnostic; XML inspection is NOT a completed Excel round-trip.

Usage: python ironcalc_xlsx_probe.py --output DIR --package-dir DIR files.xlsx ...
"""
import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path
import re
import sys
from xml.etree import ElementTree as ET
from zipfile import ZipFile


NS = {"s": "http://schemas.openxmlformats.org/spreadsheetml/2006/main"}


def inspect(path):
    with ZipFile(path) as z:
        entries = sorted(n for n in z.namelist() if not n.endswith("/"))
        wb = ET.fromstring(z.read("xl/workbook.xml"))
        props = wb.find("s:workbookPr", NS)
        names = [dict(e.attrib, formula=e.text) for e in wb.findall("s:definedNames/s:definedName", NS)]
        sheets = {}
        for p in entries:
            if not re.fullmatch(r"xl/worksheets/sheet\d+\.xml", p):
                continue
            xml = ET.fromstring(z.read(p))
            tags = Counter(e.tag.split("}")[-1] for e in xml.iter())
            formulas = {}
            for c in xml.findall(".//s:sheetData/s:row/s:c", NS):
                f = c.find("s:f", NS)
                if f is not None:
                    v = c.find("s:v", NS)
                    formulas[c.attrib["r"]] = {"formula": f.text, "formula_attrs": f.attrib, "cached_value": None if v is None else v.text, "cell_type": c.attrib.get("t", "n")}
            sheets[p] = {
                "tag_counts": {k: tags[k] for k in ["dataValidation", "mergeCell", "conditionalFormatting", "cfRule", "drawing", "oleObject", "ext"]},
                "merges": [m.attrib for m in xml.findall("s:mergeCells/s:mergeCell", NS)],
                "validations": [m.attrib for m in xml.findall("s:dataValidations/s:dataValidation", NS)],
                "conditional_formatting": [{"range": m.attrib, "rules": [{"attributes": c.attrib, "formulas": [f.text for f in c.findall("s:formula", NS)]} for c in m.findall("s:cfRule", NS)]} for m in xml.findall("s:conditionalFormatting", NS)],
                "formulas": formulas,
            }
        return {"sha256": hashlib.sha256(path.read_bytes()).hexdigest(), "bytes": path.stat().st_size, "entries": entries, "workbookPr": None if props is None else props.attrib, "defined_names": names, "sheets": sheets}


def compare(before, after):
    return {"removed_entries": sorted(set(before["entries"]) - set(after["entries"])), "added_entries": sorted(set(after["entries"]) - set(before["entries"])), "workbookPr_before": before["workbookPr"], "workbookPr_after": after["workbookPr"], "defined_names_before": before["defined_names"], "defined_names_after": after["defined_names"], "tag_counts": {p: {"before": s["tag_counts"], "after": after["sheets"].get(p, {}).get("tag_counts")} for p, s in before["sheets"].items()}}


def main():
    p = argparse.ArgumentParser()
    p.add_argument("files", nargs="+")
    p.add_argument("--output", required=True)
    p.add_argument("--package-dir")
    args = p.parse_args()
    if args.package_dir:
        sys.path.insert(0, args.package_dir)
    import ironcalc as ic
    assert ic.__version__ == "0.9.1"
    out = Path(args.output)
    out.mkdir(parents=True, exist_ok=True)
    records = []
    for arg in args.files:
        path = Path(arg)
        before = inspect(path)
        item = {"input": str(path), "before": before, "outputs": {}}
        for mode in ["noop", "recalc", "insert"]:
            try:
                model = ic.load_from_xlsx(str(path))
                if mode == "insert":
                    model.insert_rows(0, 2, 1)
                    model.evaluate()
                elif mode == "recalc":
                    model.evaluate()
                output = out / f"{path.stem}-{mode}.xlsx"
                if output.exists():
                    output.unlink()
                model.save_to_xlsx(str(output))
                after = inspect(output)
                item["outputs"][mode] = {"file": str(output), "after": after, "diff": compare(before, after)}
            except Exception as exc:
                item["outputs"][mode] = {"error": repr(exc)}
        records.append(item)
    result = {"ironcalc_version": ic.__version__, "scope": "Synthetic/upstream fixture XLSX XML diagnostics; no Excel application was opened.", "records": records}
    (out / "results.json").write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n")
    print(json.dumps([{ "input": x["input"], "outputs": {k: v.get("diff", v) for k, v in x["outputs"].items()}} for x in records], ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
