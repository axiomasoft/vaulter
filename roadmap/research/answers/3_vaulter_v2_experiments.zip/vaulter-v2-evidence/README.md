# Vaulter: пакет доказательств ко второй версии исследования

Дата исследования: **20 ноября 2026 года**. Это переносимые небольшие эксперименты на публичных пакетах и сохранённые результаты. Приватного кода Vaulter в архиве нет.

**100k benchmark not run; generator only.** Генератор нагрузки включён; измерения движков на 100 000 ячеек не выполнялись. Браузерный UI/Vue E2E, Excel application round-trip и PostgreSQL/Laravel durability в этих экспериментах не проверялись. Структура ZIP/XML сама по себе не подтверждает правильность открытия и отображения в Excel.

Состав намеренно не включает node_modules, wheel-файлы, npm tarballs, WASM/native библиотеки поставщиков, клоны репозиториев, credentials или SQLite database files. Небольшие `.xlsx` и `.icalc` являются входными/выходными документами, не библиотеками. Зависимости устанавливаются отдельно из опубликованных пакетов и используются по их лицензиям.

## 1. Структура и происхождение

| Путь | Содержание |
|---|---|
| `univer-smoke/` | Pure Node OSS tests, логи01–14, native snapshots, captured mutations, package lock |
| `ironcalc_lifecycle_probe.py` | Процессы create/agent/insert/reopen, cache/diff/name negatives |
| `ironcalc_probe_results/` | Фактические JSON results и native `.icalc` snapshots |
| `ironcalc-node-probe/` | Node native → WASM → Node probe без DOM, package lock |
| `ironcalc_xlsx_probe.py` | Import/no-op/recalc/row-insert/export и OOXML inventory |
| `ironcalc_upstream_xlsx/`, `ironcalc_date1904/` | Фактические outputs и JSON inventories |
| `pro-exchange-runtime/` | Pro Node converter scripts, package lock, outputs, diagnostics/quota receipts |
| `pro-collab-runtime/` | Pro collaboration+SQLite и Rust materializer scripts, JSON receipts; базы SQLite не включены |
| `fixtures/` | Три pinned upstream XLSX и synthetic-date1904 |
| `licenses/` | Тексты лицензий исходных репозиториев; vendor binaries не включены |
| `make_benchmark_workload.py` | Детерминированный генератор100k; движки им не измерялись |
| `MANIFEST.json`, `SHA256SUMS` | Версии, scope и хеши файлов |

`fixtures/PROVENANCE.json` содержит **точные pinned source URLs, commit, SHA256 и размеры** каждого входного файла. Upstream IronCalc fixtures взяты из v0.9.1, commit `eb9ca75bd99160c17902359d2d87225c4571c468`; приложены repository MIT и Apache2.0 licenses. Синтетический date1904 создан включённым `make_date_fixture.py` из нашей сгенерированной baseline-книги; он **не создавался и не проверялся в Excel**.

Исходные logs и result JSON сохранены без редактирования. Абсолютные `/workspace/...` пути внутри исторических JSON/stack traces описывают место исходного запуска; команды ниже не требуют такого пути. При повторном запуске scripts могут перезаписать outputs. Чтобы сохранить полученные доказательства, работайте в отдельной копии распакованного архива. Это не сбрасывает и не расширяет лицензионные квоты поставщика.

## 2. Зафиксированная среда

- Univer OSS: **1.5.2**, source commit `2c4a5dcce257e0bb6e30322b51001efa14838fee`.
- IronCalc Python / Node / WASM: **0.9.1**, source commit выше.
- Pro Exchange Node: **1.5.2**, native exchange binding **1.2.0**.
- Pro Collaboration Service и SQLite adapter: **1.5.2**.
- Pro Rust formula plugin: **1.5.2**, native binding **1.2.0**.
- Фактические runtime: **Node24.22.3**, **Python3.12.14**, Linux x86_64. package-lock фиксирует разрешённые зависимости; используйте `npm ci`, не обновляйте lock перед сравнением.

На другой платформе может потребоваться поддерживаемая поставщиком native сборка; отсутствие такой сборки — наблюдение о deployment support, не повод подменить версии. Для SQLite probe использовался Node24 с `node:sqlite`.

## 3. Проверить целостность архива

Из корня распакованного каталога:

```bash
python3 verify_bundle.py
```

Ожидается `ok: true`. Это проверка упаковки и хешей, не повторный тест движков.

## 4. Univer OSS: арифметика, restart, stale address

```bash
npm ci --prefix univer-smoke --ignore-scripts --no-audit --no-fund
node univer-smoke/smoke.mjs create
node univer-smoke/smoke.mjs update
node univer-smoke/smoke.mjs insert
node univer-smoke/smoke.mjs reopen
node univer-smoke/verify-snapshot.mjs
node univer-smoke/smoke.mjs stale-address
node univer-smoke/edge-cases.mjs unknown-resource
node univer-smoke/edge-cases.mjs cached-value
node univer-smoke/edge-cases.mjs automatic-change
```

Ожидается начальный итог35; после C3=7 итог41; после insertRowsBefore(1,1) итог41 и цена яблок10. Каждая стадия — отдельный Node-процесс. Direct snapshot verifier не импортирует движок и доказывает, что41 уже было сохранено.

Negative outcomes специально наблюдаются, а не «исправляются» тестом: новая stale запись C3=8 без Vaulter CAS меняет яблоки и даёт37; неизвестный resource исчезает при save; default WHEN_EMPTY сохраняет подложенный cache999, force исправляет41. `getValue()` при формате0.00 может быть строкой, `getRawValue()` числом.

### Ресурсы и известный failing assertion

```bash
node univer-smoke/resources.mjs create
node univer-smoke/resources.mjs insert
node univer-smoke/resources.mjs missing-plugins
```

**Вторая команда на pinned1.5.2 должна завершиться assertion error.** В проверенной content-only композиции CF range остаётся D2:D3 вместо D3:D4. Named range, DV range и image anchor передвигаются. Это negative finding, а не случайно пропущенный fail. В браузерном CF UI есть отдельный transform controller; этот пакет в pure Node композицию не включался. Изображение по example.invalid не загружается: проверена только content model/geometry.

Последняя команда показывает пропажу DV/CF/drawings/OLE resources при загрузке без соответствующих feature plugins. Подробнее — `univer-smoke/README.md`.

## 5. IronCalc: Python lifecycle и native/WASM обмен

Создайте обычное виртуальное окружение на Python3.12 и установите:

```bash
python3 -m pip install -r requirements.txt
python3 ironcalc_lifecycle_probe.py --output ironcalc_probe_results
npm ci --prefix ironcalc-node-probe --ignore-scripts --no-audit --no-fund
node ironcalc-node-probe/probe.mjs ironcalc_probe_results/r2.icalc
```

Не нужно задавать `--package-dir`, если пакет установлен в активное окружение. Опция осталась для isolated `pip --target` installations.

Lifecycle probe выполняет отдельные процессы. После записи/fsync стадии insert родитель **намеренно убивает дочерний test process**, затем открывает snapshot в новом процессе; это не завершение чужого приложения. Результат41 и цена яблок10 сохраняются. Это проверка native serialization и process lifecycle, не транзакция Vaulter.

Зафиксированные negative outcomes0.9.1:

- `resume_evaluation()` не делает evaluate: cached35 остаётся35 после save/reopen до явного evaluate→41.
- Два конкурентных raw diff в разном порядке дают **29 и41**; протокол сам по себе не обеспечивает требуемое преобразование намерения.
- Повтор insertion diff вставляет строку ещё раз.
- Именованная ссылка `Sheet1!$A$3` остаётся старой после переноса значения в A4: формула, прежде дававшая7, даёт0.
- У Native Node UserModel и WASM не совпадает набор getter API с Python UserModel/Node RawModel; probe записывает фактическое наличие методов.

## 6. IronCalc XLSX: различающие входы

```bash
python3 ironcalc_xlsx_probe.py --output ironcalc_upstream_xlsx fixtures/ironcalc-0.9.1/example.xlsx fixtures/ironcalc-0.9.1/defined_names_for_unit_test.xlsx fixtures/ironcalc-0.9.1/conditional_formatting/cf_tests.xlsx
python3 ironcalc_xlsx_probe.py --output ironcalc_date1904 fixtures/synthetic-date1904.xlsx
python3 inspect_ironcalc_dates.py --input fixtures/synthetic-date1904.xlsx --output-dir ironcalc_date1904 --json-out ironcalc_date1904/import-reads.json
```

Для каждого входа сравниваются no-op save, explicit recalc и insert row2+recalc. JSON хранит формулы, caches, имена, merges, validation/CF XML и перечень ZIP parts.

Существенные фактические negative findings: у example.xlsx при no-op исчезли31 ZIP parts; synthetic date1904 теряет workbook flag, а значение DATE после recalc расходится с оставшимися date constants. **Список удалённых частей не равен31 потерянному пользовательскому объекту**: нужно смотреть parts/relationships и Excel. `inspect_ironcalc_dates.py` — добавленный переносимый helper для повторения cell reads из исторического JSON; исходное исследование получало эти данные эквивалентным inline Python.

## 7. Univer Pro Exchange: converter и caches

Условия установки/использования Pro и доступность бесплатной квоты проверяйте у поставщика. В архиве нет Pro binaries или licence key. Во время исследования API работал без настроенного ключа с ограничением10 exports за период; **5 exports были использованы в сумме несколькими процессами**. Это наблюдение конкретной среды20.11.2026, не обещание доступности того же тарифа всем.

```bash
npm ci --prefix pro-exchange-runtime --ignore-scripts --no-audit --no-fund
node pro-exchange-runtime/quota.mjs
node pro-exchange-runtime/smoke.mjs
python3 pro-exchange-runtime/make_date_fixture.py
node pro-exchange-runtime/roundtrip.mjs fixtures/ironcalc-0.9.1/example.xlsx pro-exchange-runtime/smoke-output/example-noop.xlsx
node pro-exchange-runtime/roundtrip.mjs fixtures/synthetic-date1904.xlsx pro-exchange-runtime/smoke-output/synthetic-date1904-noop.xlsx
```

`smoke.mjs` делает3 exports; каждый roundtrip ещё1. Не повторяйте ненужные вызовы и не меняйте окружение ради обхода квоты. Если квота/лицензия не позволяет запуск, используйте включённые outputs для inspection или получите разрешённый доступ. `quota.mjs` — дополнительный read-only helper, не включает license setup.

Ожидаемая разница: после изменения входного C3 на7 default export оставляет stale formula caches35/15; FORCED export получает41/21. Формат и formula text фиксируются в smoke-results. Converter не заменяет server command protocol и не выдаёт durable Vaulter receipt. В example no-op Pro сохранял больше объектов, чем IronCalc; окончательное Excel fidelity этим не доказано. Дата1904 — отдельный gate, смотрите XML/cache diagnostics.

## 8. Univer Pro Collaboration+SQLite и Rust materializer

Перед запуском collaboration можно использовать уже включённые `univer-smoke/snapshot-v1.json`, `trace-insert.json`, `trace-update.json`. Если создаёте новое baseline, **пересоздайте оба trace на том же snapshot**, чтобы их sheet IDs совпадали:

```bash
node univer-smoke/capture-mutations.mjs insert
node univer-smoke/capture-mutations.mjs update
npm ci --prefix pro-collab-runtime --ignore-scripts --no-audit --no-fund
node pro-collab-runtime/probe.mjs init insert-first
node pro-collab-runtime/probe.mjs reopen insert-first
node pro-collab-runtime/probe.mjs init update-first
node pro-collab-runtime/probe.mjs reopen update-first
node pro-collab-runtime/materialize-probe.mjs
```

Оба init запускаются на отдельных fresh SQLite databases. Базы не включены в архив, поэтому первый запуск работает сразу. Для повторения init используйте новую рабочую копию теста; не подменяйте текущую БД, скрывая duplicate-state error. Тестовые user IDs `human`, `agent` не являются реальными учётными данными.

Используются реальные captured mutations Facade, с исключением `onlyLocal` mutations. Обе очередности insertion/update приводят к цене яблок10, груш7, итогу41; повтор одного `(unitID,sid,reqId)` возвращает прежнюю revision, включая перезапуск процесса. Но Vaulter business idempotency, impersonation ACL, Laravel transaction, Redis/multiworker и browser WebSocket здесь не проверены.

Rust materializer выдаёт новый snapshot/blocks с41, входной stale snapshot не изменяет. Блоки результата ещё требуют storage registration/metadata; script декодирует их непосредственно. Не кормите незафиксированные placeholder block IDs generic snapshot loader как готовую persistence structure.

## 9. Генератор100k: измерений нет

```bash
python3 make_benchmark_workload.py --layout sparse --out benchmark/workload-sparse.json
python3 make_benchmark_workload.py --layout dense --out benchmark/workload-dense.json
```

Генератор создаёт10 листов, ровно100000 заполненных ячеек,25000 формул,900 межлистовых ссылок,10000 массовых изменений и проверяемые before/after checksums. Для sparse last_row992105; для dense last_row2501. Входы различаются размещением одинаковой работы.

**Движки на этой нагрузке не запускались; таблица latency/RSS/p95 в отчёте остаётся открытой.** Не включайте время генерации JSON в показатель пересчёта. Полный протокол сравнения cold package startup/model load/read20/bulk/calc/persist приведён в основном документеv2.

## 10. Границы доказательства

- Логи отражают конкретные pinned versions и небольшие книги.
- Успешное native сохранение не доказывает Excel round-trip.
- Promise applied, collaboration ACK, materialized snapshot и transaction commit — разные события.
- Test suite репозиториев читалась как публичное доказательство; полная suite здесь не запускалась.
- Скрипты намеренно содержат negative probes. Падение CF assertion и описанные divergence/loss outcomes должны учитываться в выборе, а не объявляться успехом продукта.
