# Univer OSS 1.5.2 — воспроизводимые проверки Vaulter

Дата фактического запуска: 20.11.2026. Среда: Linux, Node v24.22.3, npm 11.19.1. Все прямые зависимости закреплены на 1.5.2; `package-lock.json` фиксирует транзитивные версии. Исходники, сверенные при исследовании: tag v1.5.2, commit `2c4a5dcce257e0bb6e30322b51001efa14838fee`.

Это небольшие реальные проверки публичных пакетов, не нагрузочный benchmark, не браузерный E2E, не тест XLSX и не тест PostgreSQL/Laravel durability. Все операции выполнены в обычном Node без jsdom, `document` и `window` равны `undefined`. Логи и сохранённые JSON относятся к фактическим запускам. Публичные тесты репозитория отдельно читались, но не запускались.

## Подготовка

```bash
npm ci --ignore-scripts --no-audit --no-fund
```

## Основная книга: каждый шаг — отдельный полностью завершённый Node-процесс

```bash
node smoke.mjs create
node smoke.mjs update
node smoke.mjs insert
node smoke.mjs reopen
node smoke.mjs stale-address
```

Первые четыре команды проходят assertions: 20/15/35, затем 20/21/41; после вставки строки формулы становятся `=B3*C3`, `=B4*C4`, `=SUM(Detail!D3:D4)`, итог остаётся 41, яблоки стоят 10. Последняя команда специально показывает отсутствие Vaulter CAS: новая запись по устаревшему C3 перезаписывает цену яблок на 8 и даёт 37. Эта ветка не сохраняется.

`getValue()` с подключённым numfmt и форматом `0.00` возвращал форматированную строку; для чисел используйте `getRawValue()`/`getRawValues()`. Тип берётся из `getCellDataGrid()`, формула — `getFormula()`/`getFormulas()`, формат — `getNumberFormat()`.

## Различающие проверки

```bash
node edge-cases.mjs unknown-resource
node edge-cases.mjs cached-value
node edge-cases.mjs automatic-change
```

Фактически наблюдалось:

- Неизвестный resource sentinel исчезает из результата `wb.save()`.
- Подложенный кэш 999 остаётся после default WHEN_EMPTY initialization и applied barrier. Принудительный пересчёт восстанавливает 41.
- Изменение C4 на 8 само запускает пересчёт; барьер без ручного force возвращает итог 44.

## Ресурсы: успешные и неуспешная проверка

```bash
node resources.mjs create
node resources.mjs insert
node resources.mjs missing-plugins
```

`create` проходит. Созданы именованный диапазон Totals, decimal validation, conditional formatting и image model с явными размерами. Реальное изображение по URL не загружается и не рисуется: проверяется модель/геометрия.

`insert` ДОЛЖНА СЕЙЧАС ЗАВЕРШИТЬСЯ С ОШИБКОЙ assertion на исходных пакетах 1.5.2: в tested content-only composition диапазон CF остаётся D2:D3, тогда как ожидается D3:D4. Именованный диапазон, validation и image anchor смещаются правильно. Это обнаруженный пробел конкретной headless-композиции, не утверждение, что браузерный Univer не поддерживает перенос CF.

Причина по исходникам: `ConditionalFormattingFormulaRefRangeController`, который регистрирует перенос ranges/formulas, находится в `sheets-conditional-formatting-ui` и активируется UI plugin. Content plugin только помечает затронутые CF rules dirty. Исправление/официальная headless registration должны стать входным условием для серверных структурных изменений книг с CF.

`missing-plugins` показывает, что при загрузке той же книги только минимальным набором исчезают ресурсы CF, DV, drawings и OLE; named ranges сохраняются, потому что входят в базовый Sheets plugin.

## Диагностика команд для проверки collaboration SDK

```bash
node capture-mutations.mjs insert
node capture-mutations.mjs update
```

Обе команды загружают один snapshot-v1. `trace-*.json` содержит реальные исходящие mutations, а не вручную придуманные параметры. Служебные `onlyLocal: true` нельзя отправлять как пользовательские изменения. Этот диагностический скрипт использует `univer.__getInjector()`; это не рекомендуемый публичный контракт инструмента агента. Продуктовый адаптер должен использовать Facade и поддерживаемый collaboration SDK.

## Ограничения подтверждений

`setValue`, `setValues`, `insertRowsBefore` и `save` синхронны, но готовность формул асинхронна. `onCalculationResultApplied(10000)` не подтверждает транзакцию хранилища, не проверяет правильность ранее сохранённого кэша и не сообщает, что формулы не вернули `#REF!`/`#VALUE!`. В прототипе нужны независимый read-back, проверка результата, журнал operation_id и version CAS. В production оборачивайте жизненный цикл в `try/finally { univer.dispose(); }`; timeout/ошибка должны закрывать попытку без фиксации новой версии.

## Прямая проверка сохранённых кэшей, без runtime

```bash
node verify-snapshot.mjs
```

Эта команда напрямую читает snapshot-v3.json и подтверждает сохранённые значения 10/7/20/21/41, тип2 и перемещённые формулы. Она не импортирует Univer, поэтому не может незаметно исправить кэш пересчётом. Фактический вывод в 14-direct-snapshot-cache.log.
