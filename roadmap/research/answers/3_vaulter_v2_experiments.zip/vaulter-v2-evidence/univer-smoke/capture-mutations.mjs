/** Reproducible test on Univer OSS 1.5.2; Node 24.22.3; no DOM/Canvas/browser. */
import {readFileSync,writeFileSync} from 'node:fs';
import {strict as assert} from 'node:assert';
import {LocaleType, Univer, CellValueType} from '@univerjs/core';
import {FUniver} from '@univerjs/core/facade';
import {UniverRenderEnginePlugin} from '@univerjs/engine-render';
import {UniverFormulaEnginePlugin} from '@univerjs/engine-formula';
import {UniverDocsPlugin} from '@univerjs/docs';
import {UniverSheetsPlugin} from '@univerjs/sheets';
import {UniverSheetsFormulaPlugin} from '@univerjs/sheets-formula';
import {UniverSheetsNumfmtPlugin} from '@univerjs/sheets-numfmt';
import '@univerjs/engine-formula/facade';
import '@univerjs/sheets/facade';
import '@univerjs/sheets-formula/facade';
import '@univerjs/sheets-numfmt/facade';

import {ICommandService} from '@univerjs/core';
const base=new URL('./',import.meta.url);const phase=process.argv[2]??'insert';
const univer=new Univer({locale:LocaleType.EN_US,locales:{}});
for(const P of [UniverRenderEnginePlugin,UniverFormulaEnginePlugin,UniverDocsPlugin,UniverSheetsPlugin,UniverSheetsFormulaPlugin,UniverSheetsNumfmtPlugin])univer.registerPlugin(P);
const api=FUniver.newAPI(univer);const formula=api.getFormula();const wb=api.createWorkbook(JSON.parse(readFileSync(new URL('snapshot-v1.json',base),'utf8')));
let applied=formula.onCalculationResultApplied(10000);formula.executeCalculation();await applied;
const commands=[];const collab=[];
// Diagnostic observer; the application should use supported Facade/SDK transport rather than replaying arbitrary internals.
const cs=univer.__getInjector().get(ICommandService);
const d1=cs.onCommandExecuted((command,options)=>commands.push(JSON.parse(JSON.stringify({command,options}))));
const d2=cs.onMutationExecutedForCollab((command,options)=>collab.push(JSON.parse(JSON.stringify({command,options}))));
if(phase==='insert')wb.getSheetByName('Detail').insertRowsBefore(1,1);
else wb.getSheetByName('Detail').getRange('C3').setValue(7);
d1.dispose();d2.dispose();
const output={phase,unitId:wb.getId(),sheets:wb.getSheets().map(s=>({id:s.getSheetId(),name:s.getSheetName()})),commands,collab};
writeFileSync(new URL(`trace-${phase}.json`,base),JSON.stringify(output,null,2));console.log(JSON.stringify(output));univer.dispose();
