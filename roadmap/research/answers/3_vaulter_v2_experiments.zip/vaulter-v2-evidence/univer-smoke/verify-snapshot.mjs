// Verify persisted formula caches directly, before loading any calculation runtime.
import {readFileSync} from 'node:fs';
import {strict as assert} from 'node:assert';
const snapshot=JSON.parse(readFileSync(new URL('./snapshot-v3.json',import.meta.url),'utf8'));
const detail=Object.values(snapshot.sheets).find(s=>s.name==='Detail');
const summary=Object.values(snapshot.sheets).find(s=>s.name==='Summary');
const apple=detail.cellData[2][2]; const pear=detail.cellData[3][2];
const d3=detail.cellData[2][3];const d4=detail.cellData[3][3];const total=summary.cellData[1][1];
assert.equal(apple.v,10);assert.equal(pear.v,7);assert.equal(d3.v,20);assert.equal(d4.v,21);assert.equal(total.v,41);
assert.equal(d3.f,'=B3*C3');assert.equal(d4.f,'=B4*C4');assert.equal(total.f,'=SUM(Detail!D3:D4)');
for(const c of [apple,pear,d3,d4,total])assert.equal(c.t,2);
console.log(JSON.stringify({stage:'persisted-file-before-any-runtime-or-recalculation',apple,pear,d3,d4,total}));
