// Portable read-only helper added during evidence packaging. No export or license mutation.
import {getExportQuota} from '@univerjs-pro/exchange-node';
console.log(JSON.stringify(await getExportQuota(),null,2));
