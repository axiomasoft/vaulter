import fs from 'node:fs/promises';
import { UniverInstanceType, LocaleType, CellValueType } from '@univerjs/core';
import { ExchangeFormat, FormulaCalculationMode, exportToFile, importFile, getExportQuota } from '@univerjs-pro/exchange-node';

const output = new URL('./smoke-output/', import.meta.url);
await fs.mkdir(output, { recursive: true });
const numeric = (v, extra = {}) => ({ v, t: CellValueType.NUMBER, ...extra });
const text = (v) => ({ v, t: CellValueType.STRING });
const workbook = {
  id: 'vaulter-exchange-smoke', rev: 1, name: 'Vaulter Detail Summary', appVersion: '1.5.2', locale: LocaleType.EN_US,
  sheetOrder: ['detail', 'summary'], styles: { money: { n: { pattern: '0.00' } } }, resources: [],
  sheets: {
    detail: { id: 'detail', name: 'Detail', rowCount: 100, columnCount: 26, cellData: {
      0: { 0: text('Товар'), 1: text('Количество'), 2: text('Цена'), 3: text('Сумма') },
      1: { 0: text('Яблоки'), 1: numeric(2), 2: numeric(10, { s: 'money' }), 3: numeric(20, { f: '=B2*C2', s: 'money' }) },
      2: { 0: text('Груши'), 1: numeric(3), 2: numeric(5, { s: 'money' }), 3: numeric(15, { f: '=B3*C3', s: 'money' }) }
    } },
    summary: { id: 'summary', name: 'Summary', rowCount: 100, columnCount: 26, cellData: {
      1: { 0: text('Итого'), 1: numeric(35, { f: '=SUM(Detail!D2:D3)', s: 'money' }) }
    } }
  }
};
const opts = { type: UniverInstanceType.UNIVER_SHEET, format: ExchangeFormat.XLSX };
const file = (name) => new URL(name, output).pathname;
await exportToFile(workbook, file('baseline.xlsx'), { ...opts, formulaCalculation: FormulaCalculationMode.FORCED });
const imported = await importFile(file('baseline.xlsx'), { ...opts, formulaCalculation: FormulaCalculationMode.NO });
const byName = (wb, name) => Object.values(wb.sheets).find(s => s.name === name);
byName(imported, 'Detail').cellData[2][2].v = 7;
const diagnosticBatches = [];
await exportToFile(imported, file('changed-default.xlsx'), { ...opts, onDiagnostics: x => diagnosticBatches.push(x) });
await exportToFile(imported, file('changed-forced.xlsx'), { ...opts, formulaCalculation: FormulaCalculationMode.FORCED, onDiagnostics: x => diagnosticBatches.push(x) });
const summarize = (wb) => {
  const detail = byName(wb, 'Detail'); const summary = byName(wb, 'Summary');
  const pick = (s, r, c) => { const cell = s.cellData[r]?.[c]; return { ...cell, effectiveStyle: typeof cell?.s === 'string' ? wb.styles[cell.s] : cell?.s }; };
  return { detailId: detail.id, summaryId: summary.id, pricePear: pick(detail,2,2), apple:pick(detail,1,3), pear:pick(detail,2,3), sum:pick(summary,1,1), resources: wb.resources.map(r => r.name) };
};
const results = {};
for (const name of ['baseline.xlsx','changed-default.xlsx','changed-forced.xlsx']) {
  results[name] = summarize(await importFile(file(name), { ...opts, formulaCalculation: FormulaCalculationMode.NO }));
}
const report = { observedAt: new Date().toISOString(), runtime: process.version, platform:process.platform, arch:process.arch,
  versions: { exchangeNode:'1.5.2', officeNativeBinding:'1.2.0' }, results, diagnosticBatches,
  originalInputAfterExport: summarize(workbook), mutatedInputAfterForcedExport:summarize(imported), quota: await getExportQuota() };
await fs.writeFile(file('smoke-results.json'), JSON.stringify(report,null,2));
console.log(JSON.stringify(report,null,2));
