from pathlib import Path
from zipfile import ZipFile
from hashlib import sha256
import xml.etree.ElementTree as ET
import json,sys

ns={'s':'http://schemas.openxmlformats.org/spreadsheetml/2006/main'}
def inventory(path):
    p=Path(path)
    with ZipFile(p) as z:
        names=z.namelist()
        result={'path':str(p),'sha256':sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size,'parts':len(names)}
        for label,prefix in [('charts','xl/charts/chart'),('pivotTables','xl/pivotTables/pivotTable'),('pivotCacheDefinitions','xl/pivotCache/pivotCacheDefinition'),('tables','xl/tables/table'),('comments','xl/comments'),('drawings','xl/drawings/drawing')]:
            result[label]=[n for n in names if n.startswith(prefix) and n.endswith('.xml')]
        result['media']=[n for n in names if n.startswith('xl/media/')]
        result['embeddings']=[n for n in names if n.startswith('xl/embeddings/')]
        wb=ET.fromstring(z.read('xl/workbook.xml'))
        pr=wb.find('s:workbookPr',ns)
        result['date1904']=pr.attrib.get('date1904','0') if pr is not None else '0'
        result['definedNames']=[dict(d.attrib,text=d.text) for d in wb.findall('s:definedNames/s:definedName',ns)]
        result['sheets']={}
        for n in names:
            if n.startswith('xl/worksheets/sheet') and n.endswith('.xml'):
                sheet=ET.fromstring(z.read(n))
                formulae=[]
                for c in sheet.findall('.//s:c',ns):
                    f=c.find('s:f',ns)
                    v=c.find('s:v',ns)
                    if f is not None:formulae.append(dict(address=c.get('r'),formula=f.text,cached=v.text if v is not None else None))
                result['sheets'][n]={
                    'formulaCount':len(formulae),'formulae':formulae,
                    'merges':[m.get('ref') for m in sheet.findall('s:mergeCells/s:mergeCell',ns)],
                    'dataValidations':[dict(d.attrib,formula1=d.findtext('s:formula1',default='',namespaces=ns),formula2=d.findtext('s:formula2',default='',namespaces=ns)) for d in sheet.findall('s:dataValidations/s:dataValidation',ns)],
                    'conditionalFormatting':[{'sqref':c.get('sqref'),'rules':[dict(r.attrib,formula=r.findtext('s:formula',default='',namespaces=ns)) for r in c.findall('s:cfRule',ns)]} for c in sheet.findall('s:conditionalFormatting',ns)]}
                if 'date1904' in str(p):
                    result['sheets'][n]['dateCells']=[{'r':c.get('r'),'s':c.get('s'),'t':c.get('t'),'v':c.findtext('s:v',default=None,namespaces=ns),'f':c.findtext('s:f',default=None,namespaces=ns)} for c in sheet.findall('.//s:c',ns) if c.get('r') in [f'A{x}' for x in range(5,12)]]
        return result
results=[inventory(p) for p in sys.argv[1:]]
print(json.dumps(results,ensure_ascii=False,indent=2))
