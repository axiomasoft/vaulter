import fs from 'node:fs/promises';
import { UniverInstanceType } from '@univerjs/core';
import { ExchangeFormat, FormulaCalculationMode, importFile, exportToFile, getExportQuota } from '@univerjs-pro/exchange-node';

const [input, output] = process.argv.slice(2);
if (!input || !output) throw new Error('Usage: node roundtrip.mjs input.xlsx output.xlsx');
const diagnostics = [];
const opts = { type: UniverInstanceType.UNIVER_SHEET, format: ExchangeFormat.XLSX,
  formulaCalculation: FormulaCalculationMode.NO, onDiagnostics: d => diagnostics.push(d) };
const workbook = await importFile(input, opts);
await fs.writeFile(`${output}.import.json`, JSON.stringify(workbook));
await exportToFile(workbook, output, opts);
const report = { input, output, resources: workbook.resources.map(r => ({name:r.name, bytes:JSON.stringify(r.data).length})),
  dateSystem: workbook.date1904, workbookKeys:Object.keys(workbook), diagnostics, quota:await getExportQuota() };
await fs.writeFile(`${output}.result.json`, JSON.stringify(report,null,2));
console.log(JSON.stringify(report,null,2));
