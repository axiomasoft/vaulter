"""Create a narrow OOXML fixture by changing a converter-generated baseline.

This is a synthetic XML fixture, not an Excel-authored workbook or an Excel
round-trip test. No source file is modified. The date1904 bit is set explicitly.
"""
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
from copy import deepcopy
import xml.etree.ElementTree as ET
import json

base=Path(__file__).resolve().parent/'smoke-output'
ns='http://schemas.openxmlformats.org/spreadsheetml/2006/main'
ET.register_namespace('',ns)
ET.register_namespace('r','http://schemas.openxmlformats.org/officeDocument/2006/relationships')
q=lambda n:f'{{{ns}}}{n}'
with ZipFile(base/'baseline.xlsx') as z:
    parts={n:z.read(n) for n in z.namelist()}
workbook=ET.fromstring(parts['xl/workbook.xml'])
prop=workbook.find(q('workbookPr'))
if prop is None:
    prop=ET.Element(q('workbookPr'))
    workbook.insert(0,prop)
prop.set('date1904','1')
parts['xl/workbook.xml']=ET.tostring(workbook,encoding='utf-8',xml_declaration=True)
styles=ET.fromstring(parts['xl/styles.xml'])
xfs=styles.find(q('cellXfs'))
style_index=len(xfs)
xf=deepcopy(xfs[0]);xf.set('numFmtId','14');xf.set('applyNumberFormat','1')
xfs.append(xf);xfs.set('count',str(len(xfs)))
parts['xl/styles.xml']=ET.tostring(styles,encoding='utf-8',xml_declaration=True)
sheet=ET.fromstring(parts['xl/worksheets/sheet1.xml'])
data=sheet.find(q('sheetData'))
for rownum,serial in enumerate([0,1,59,60,61,44561],start=5):
    row=ET.SubElement(data,q('row'),{'r':str(rownum)})
    cell=ET.SubElement(row,q('c'),{'r':f'A{rownum}','s':str(style_index)})
    ET.SubElement(cell,q('v')).text=str(serial)
row=ET.SubElement(data,q('row'),{'r':'11'})
cell=ET.SubElement(row,q('c'),{'r':'A11','s':str(style_index)})
ET.SubElement(cell,q('f')).text='DATE(2026,1,1)'
ET.SubElement(cell,q('v')).text='44561'
dim=sheet.find(q('dimension'))
if dim is not None:dim.set('ref','A1:D11')
parts['xl/worksheets/sheet1.xml']=ET.tostring(sheet,encoding='utf-8',xml_declaration=True)
with ZipFile(base/'synthetic-date1904.xlsx','w',ZIP_DEFLATED) as z:
    for n,b in parts.items():z.writestr(n,b)
print(json.dumps({'path':str(base/'synthetic-date1904.xlsx'),'provenance':'synthetic OOXML patch to Pro-generated baseline','date1904':True,'serials':[0,1,59,60,61,44561],'A11':{'formula':'DATE(2026,1,1)','cache':44561}}))
