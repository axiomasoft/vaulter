import fs from 'node:fs/promises';
import { createHash } from 'node:crypto';
import { materializeWorkbookSnapshot } from '@univerjs-pro/engine-formula-rust';

const source=JSON.parse(await fs.readFile(new URL('../univer-smoke/snapshot-v1.json',import.meta.url),'utf8'));
const sheet=Object.values(source.sheets).find(s=>s.name==='Detail');
const summary=Object.values(source.sheets).find(s=>s.name==='Summary');
sheet.cellData[2][2].v=7;
const before=JSON.stringify(source);
const hash=v=>createHash('sha256').update(v).digest('hex');
const aggregate=await materializeWorkbookSnapshot(source,source.id,2);
await fs.writeFile(new URL('./materialize-aggregate.json',import.meta.url),JSON.stringify(aggregate));
const blocks=Object.values(aggregate.sheetBlocks).flat();
// The Rust materializer returns not-yet-persisted blocks grouped by sheet ID.
// In this result blockMeta.blocks is empty and block IDs are placeholders.
// Inspect each group's bytes directly; do not flatten and feed to the generic
// snapshot loader before storing/assigning globally unique block IDs and refs.
const decodeSheet=sheetId=>Object.assign({},...aggregate.sheetBlocks[sheetId].map(block=>JSON.parse(Buffer.from(block.data).toString('utf8'))));
const detailCells=decodeSheet(sheet.id);
const summaryCells=decodeSheet(summary.id);
const report={time:new Date().toISOString(),node:process.version,versions:{rustPlugin:'1.5.2',rustBinding:'1.2.0'},
  dom:{window:typeof window,document:typeof document},input:{C3:sheet.cellData[2][2],D3:sheet.cellData[2][3],sum:summary.cellData[1][1]},
  inputUnchanged:before===JSON.stringify(source),inputSha256:hash(before),outputRevision:aggregate.snapshot.rev,
  sheetBlockCount:blocks.length,calculationStats:aggregate.calculationStats,warnings:aggregate.warnings,
  output:{C3:detailCells[2]?.[2],D2:detailCells[1]?.[3],D3:detailCells[2]?.[3],sum:summaryCells[1]?.[1],numberFormat:source.styles?.[detailCells[2]?.[3]?.s]?.n},
  blockShape:blocks.map(b=>({keys:Object.keys(b),id:b.id,unitID:b.unitID,dataType:typeof b.data,dataConstructor:b.data?.constructor?.name,dataLength:b.data?.length})),blockMeta:aggregate.snapshot.workbook?.blockMeta};
await fs.writeFile(new URL('./materialize-probe-results.json',import.meta.url),JSON.stringify(report,null,2));
console.log(JSON.stringify(report,null,2));
