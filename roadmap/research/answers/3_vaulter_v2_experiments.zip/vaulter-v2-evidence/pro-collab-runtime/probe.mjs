import fs from 'node:fs/promises';
import { SQLiteDatabaseAdapter } from '@univerjs-pro/collaboration-database-sqlite';
import { UniverCollabService, UnitSnapshotMaterializer } from '@univerjs-pro/collaboration-service';
import { transformSnapshotToWorkbookData } from '@univerjs-pro/collaboration';
import { UniverType } from '@univerjs/protocol';

const [phase = 'init', order = 'insert-first'] = process.argv.slice(2);
const base = new URL('../univer-smoke/', import.meta.url);
const out = new URL(`./${order}/`, import.meta.url);
await fs.mkdir(out, {recursive:true});
const filename = new URL('collaboration.sqlite',out).pathname;
const source = JSON.parse(await fs.readFile(new URL('snapshot-v1.json',base),'utf8'));
const traceInsert = JSON.parse(await fs.readFile(new URL('trace-insert.json',base),'utf8'));
const traceUpdate = JSON.parse(await fs.readFile(new URL('trace-update.json',base),'utf8'));
const type=UniverType.UNIVER_SHEET;
const mutations = trace => trace.collab.filter(x => x.command.type === 2 && !x.options?.onlyLocal)
  .map(x=>({id:x.command.id,data:JSON.stringify(x.command.params)}));
const input = (sid,trace,userID) => ({changeset:{unitID:source.id,type,baseRev:1,revision:2,sid,reqId:1,userID,memberID:userID,
  mutations:mutations(trace)}});
const human=input('human-insert',traceInsert,'human');
const agent=input('agent-price',traceUpdate,'agent');
const ctx=inp=>({userID:inp.changeset.userID,memberID:inp.changeset.memberID});
const db=new SQLiteDatabaseAdapter({filename});
const service=new UniverCollabService({dbAdapter:db,snapshotPolicy:false,runtime:{execution:{mode:'in-process'}}});
const materializer=new UnitSnapshotMaterializer({execution:{mode:'in-process'}});
const inspect=async()=>{
 const recovery=await service.getUnitLoadDataWithBlocks({unitID:source.id,type,revision:0},{userID:'agent'});
 const aggregate=await materializer.materializeSnapshot(recovery);
 const wb=await transformSnapshotToWorkbookData(aggregate.snapshot,aggregate.sheetBlocks);
 const detail=Object.values(wb.sheets).find(s=>s.name==='Detail');
 const summary=Object.values(wb.sheets).find(s=>s.name==='Summary');
 return {revision:recovery.targetRevision,snapshotRevision:recovery.snapshot.rev,replayCount:recovery.changesets.length,
  cells:{C3:detail.cellData[2]?.[2],C4:detail.cellData[3]?.[2],D3:detail.cellData[2]?.[3],D4:detail.cellData[3]?.[3],sum:summary.cellData[1]?.[1]},
  resources:wb.resources.map(r=>r.name)};
};
const result={phase,order,node:process.version,versions:{service:'1.5.2',sqlite:'1.5.2'},dom:{window:typeof window,document:typeof document},events:[]};
try {
 if(phase==='init') {
  source.rev=1;
  result.created=await service.createUnitFromData({type,data:source},{userID:'agent'});
  const ordered=order==='insert-first'?[human,agent]:[agent,human];
  for(const item of ordered) result.events.push({sid:item.changeset.sid,result:await service.submitChangeset(item,ctx(item))});
  result.after=await inspect();
  result.repeat=await service.submitChangeset(agent,ctx(agent));
 } else if(phase==='reopen') {
  result.afterReopen=await inspect();
  result.repeat=await service.submitChangeset(agent,ctx(agent));
  result.afterRepeat=await inspect();
 } else throw new Error('Unknown phase');
 await fs.writeFile(new URL(`${phase}.json`,out),JSON.stringify(result,null,2));
 console.log(JSON.stringify(result,null,2));
} finally {
 await materializer.dispose();
 await service.dispose();
 await db.dispose();
}
