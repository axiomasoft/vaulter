#!/usr/bin/env python3
"""Verify packaged evidence bytes without importing any spreadsheet engine."""
from pathlib import Path
import hashlib,json,sys
root=Path(__file__).resolve().parent
manifest=json.loads((root/'MANIFEST.json').read_text())
failures=[]
for item in manifest['files']:
    p=root/item['path']
    if not p.is_file():failures.append({'path':item['path'],'error':'missing'});continue
    actual=hashlib.sha256(p.read_bytes()).hexdigest()
    if actual!=item['sha256']:failures.append({'path':item['path'],'error':'sha256 mismatch','actual':actual})
print(json.dumps({'ok':not failures,'checked_files':len(manifest['files']),'failures':failures},ensure_ascii=False,indent=2))
sys.exit(1 if failures else 0)
