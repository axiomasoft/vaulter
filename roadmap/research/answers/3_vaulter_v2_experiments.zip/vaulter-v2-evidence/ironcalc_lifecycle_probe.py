#!/usr/bin/env python3
"""Executed research probe, pinned to ironcalc==0.9.1.

Install: python -m pip install ironcalc==0.9.1
Run: python ironcalc_lifecycle_probe.py --output DIR
The optional --package-dir only locates an isolated pip --target install.
This probes engine semantics, NOT Vaulter's unimplemented persistence protocol.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import platform
import subprocess
import sys


def boot(package_dir):
    if package_dir:
        sys.path.insert(0, package_dir)
    import ironcalc as ic
    assert ic.__version__ == "0.9.1", ic.__version__
    return ic


def read_cell(m, sheet, row, column):
    return {
        "value": m.get_cell_value(sheet, row, column),
        "formula": m.get_cell_formula(sheet, row, column),
        "type": str(m.get_cell_type(sheet, row, column)),
        "number_format": m.get_cell_style(sheet, row, column)["num_fmt"],
        "display": m.get_formatted_cell_value(sheet, row, column),
    }


def snapshot(m, shifted=False):
    apple, pear = (3, 4) if shifted else (2, 3)
    return {
        f"Detail!A{apple}": read_cell(m, 0, apple, 1),
        f"Detail!C{apple}": read_cell(m, 0, apple, 3),
        f"Detail!D{apple}": read_cell(m, 0, apple, 4),
        f"Detail!A{pear}": read_cell(m, 0, pear, 1),
        f"Detail!C{pear}": read_cell(m, 0, pear, 3),
        f"Detail!D{pear}": read_cell(m, 0, pear, 4),
        "Summary!B2": read_cell(m, 1, 2, 2),
    }


def new_book(ic):
    m = ic.UserModel("Vaulter probe", "en", "UTC", "en")
    m.rename_sheet(0, "Detail")
    m.new_sheet()
    m.rename_sheet(1, "Summary")
    m.pause_evaluation()
    rows = [
        ["Товар", "Количество", "Цена", "Сумма"],
        ["Яблоки", "2", "10", "=B2*C2"],
        ["Груши", "3", "5", "=B3*C3"],
    ]
    for r, cells in enumerate(rows, start=1):
        for c, value in enumerate(cells, start=1):
            m.set_user_input(0, r, c, value)
    m.set_user_input(1, 2, 2, "=SUM(Detail!D2:D3)")
    m.update_range_style(0, 2, 3, 3, 4, "num_fmt", "0.00")
    m.update_range_style(1, 2, 2, 2, 2, "num_fmt", "0.00")
    m.resume_evaluation()
    m.evaluate()  # resume_evaluation only removes the pause flag.
    return m


def save(m, path):
    raw = m.to_bytes()
    with path.open("wb") as f:
        f.write(raw)
        f.flush()
        os.fsync(f.fileno())
    return {"bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest()}


def stage(args):
    ic = boot(args.package_dir)
    out = Path(args.output)
    if args.stage == "create":
        m = new_book(ic)
        result = snapshot(m)
        assert m.get_cell_value(1, 2, 2) == 35
        save_info = save(m, out / "r1.icalc")
    elif args.stage == "agent":
        m = ic.UserModel.from_bytes((out / "r1.icalc").read_bytes())
        m.set_user_input(0, 3, 3, "7")
        result = snapshot(m)
        assert m.get_cell_value(1, 2, 2) == 41
        save_info = save(m, out / "r2.icalc")
    elif args.stage == "insert":
        m = ic.UserModel.from_bytes((out / "r2.icalc").read_bytes())
        m.insert_rows(0, 2, 1)
        result = snapshot(m, shifted=True)
        assert m.get_cell_formula(0, 3, 4) == "=B3*C3"
        assert m.get_cell_formula(0, 4, 4) == "=B4*C4"
        assert m.get_cell_formula(1, 2, 2) == "=SUM(Detail!D3:D4)"
        assert m.get_cell_value(1, 2, 2) == 41
        save_info = save(m, out / "r3.icalc")
    elif args.stage == "reopen":
        m = ic.UserModel.from_bytes((out / "r3.icalc").read_bytes())
        result = snapshot(m, shifted=True)
        assert m.get_cell_value(1, 2, 2) == 41
        assert m.get_cell_value(0, 3, 3) == 10
        before = snapshot(m, shifted=True)
        m.evaluate()
        assert before == snapshot(m, shifted=True)
        save_info = {"can_undo_after_reload": m.can_undo(), "explicit_evaluate_same": True}
    else:
        raise ValueError(args.stage)
    print(json.dumps({"stage": args.stage, "pid": os.getpid(), "snapshot": result, "saved": save_info}, ensure_ascii=False), flush=True)
    if args.stage == "insert":
        # Parent kills this process after a flushed + fsynced snapshot exists.
        sys.stdin.readline()


def additional_probes(ic):
    m = new_book(ic)
    m.pause_evaluation()
    m.set_user_input(0, 3, 3, "7")
    while_paused = m.get_cell_value(1, 2, 2)
    m.resume_evaluation()
    after_resume = m.get_cell_value(1, 2, 2)
    saved_stale = m.to_bytes()
    reopened_stale = ic.UserModel.from_bytes(saved_stale).get_cell_value(1, 2, 2)
    m.evaluate()
    after_evaluate = m.get_cell_value(1, 2, 2)
    assert [while_paused, after_resume, reopened_stale, after_evaluate] == [35, 35, 35, 41]

    base = new_book(ic)
    state = base.to_bytes()
    alice = ic.UserModel.from_bytes(state)
    bob = ic.UserModel.from_bytes(state)
    alice.insert_rows(0, 2, 1)
    alice_diff = alice.flush_send_queue()
    bob.set_user_input(0, 3, 3, "7")
    bob_diff = bob.flush_send_queue()
    alice.apply_external_diffs(bob_diff)
    bob.apply_external_diffs(alice_diff)
    conflict = {"human_then_agent_diff": snapshot(alice, True), "agent_then_human_diff": snapshot(bob, True)}

    dup = ic.UserModel.from_bytes(state)
    dup.apply_external_diffs(alice_diff)
    one = [dup.get_cell_value(0, i, 1) for i in range(1, 6)]
    dup.apply_external_diffs(alice_diff)
    two = [dup.get_cell_value(0, i, 1) for i in range(1, 6)]
    named = ic.UserModel("named-range")
    named.set_user_input(0, 3, 1, "7")
    named.new_defined_name("PearPrice", None, "Sheet1!$A$3")
    named.set_user_input(0, 1, 2, "=PearPrice")
    names_before = named.get_defined_name_list()
    value_before = named.get_cell_value(0, 1, 2)
    named.insert_rows(0, 2, 1)
    names_after = named.get_defined_name_list()
    value_after = named.get_cell_value(0, 1, 2)
    assert value_before == 7 and value_after == 0
    assert named.get_cell_value(0, 4, 1) == 7
    return {
        "pause_resume_stale_cache": {"while_paused": while_paused, "after_resume": after_resume, "after_save_reload_without_evaluate": reopened_stale, "after_explicit_evaluate": after_evaluate},
        "concurrent_diff_conflict": conflict,
        "duplicate_insert_diff": {"one_application_column_A": one, "two_applications_column_A": two},
        "defined_name_after_insert": {"names_before": names_before, "names_after": names_after, "formula_result_before": value_before, "formula_result_after": value_after, "value_at_shifted_A4": named.get_cell_value(0, 4, 1)},
        "scope": "Pure engine probes. No browser/Excel/SQL transaction/OCC/idempotency adapter was executed.",
    }


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--output", default="ironcalc_probe_results")
    p.add_argument("--package-dir")
    p.add_argument("--stage", choices=["create", "agent", "insert", "reopen"])
    args = p.parse_args()
    if args.stage:
        return stage(args)
    out = Path(args.output).absolute()
    out.mkdir(parents=True, exist_ok=True)
    ic = boot(args.package_dir)
    logs = []
    for name in ["create", "agent", "insert", "reopen"]:
        command = [sys.executable, str(Path(__file__).absolute()), "--output", str(out), "--stage", name]
        if args.package_dir:
            command.extend(["--package-dir", args.package_dir])
        process = subprocess.Popen(command, text=True, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        record = process.stdout.readline()
        if not record:
            raise RuntimeError(process.communicate())
        result = json.loads(record)
        if name == "insert":
            process.kill()
        process.wait(timeout=10)
        result["exit_code"] = process.returncode
        logs.append(result)
    result = {"version": ic.__version__, "python": sys.version, "platform": platform.platform(), "lifecycle": logs, "extra": additional_probes(ic)}
    (out / "results.json").write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n")
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
